/* simx.h,v 1.0 1993/10/21 19:07:55 NIST */
/* SHIV : cleaned up for CISE */
/*
 *
 * $Log:	simx.h,v $
 * Revision 3.0  97/01/31  00:26:51  goyal
 * Final Revision
 * 
 * Revision 2.0  97/01/31  00:25:40  goyal
 * Final Revision
 * 
 * Revision 1.2  97/01/22  15:09:22  goyal
 * Given to students
 * 
 * Revision 1.1  97/01/18  17:14:10  goyal
 * Initial revision
 * 
 * Revision 2.1  1996/05/28 05:57:31  tlin
 * bump to v 2.1; before tcl/tk conversion
 *
 * Revision 0.1  1996/05/27 22:51:43  tlin
 * test
 *
 * Revision 0.0  96/04/26  15:34:32  goyal
 * Lab1
 * 
 * Revision 1.0  96/04/24  15:02:06  shivkuma
 * Lab 1
 * 
 * Revision 1.1  96/04/22  00:00:08  shivkuma
 * Version Before Putting in User-Friendly names
 * 
 * Revision 0.0  96/02/21  00:44:04  goyal
 * Initial Revision
 * 
 *
 *
 */


#ifndef SIMX_H
#define SIMX_H
#include "simx1.h"
#include "component.h"
#include "list.h"

typedef Component COMPONENT;
typedef Param PARAM;
typedef Neighbor NEIGHBOR;


#define RightButton Button3
#define LeftButton Button1
#define MiddleButton Button2


list *comps;
list *route_table;

typedef struct {
  short button;
  short key;
} OPTION;

typedef struct {
 OPTION select;
 OPTION move;
 OPTION resize;
 OPTION create;
 OPTION connection;
 OPTION route;
 OPTION raise;
 OPTION lower;
} KEY_BINDING;

typedef struct _XCOMPONENT {
  COMPONENT *scomponent;     /* pointer to object's component */
  Window comp_window;  /* window id of component window */
  Window info_window;   /* window id of information window */
  GC back_gc;			/* Pointer to gc to clear infowindow */
  short which_one;         /* COMP_WINDOW or INFO_WINDOW*/
  int hposition;
  int wposition;
  int x,y;
  int info_window_vertical_padding;
  int width, height;  /* width and height of info window */
  int info_font;
  int info_font_info;
  Param **p_list;     /* Array of pointers to parameters
			in info windows (IN ORDER) */
  int num_params;
  Param **m_list;     /* Array of params that have meters */
  int num_meters;
} XCOMPONENT;

typedef struct _ENVIRONMENT  {

  Display *the_display;
  short int monochrome;
  int the_screen;
  char *pr_name;

  Window back_window;
  Window clock_window;
  Window icon_window;
  Window text_window;

  Font info_font;
  Font info_big_font;
  Font comp_font;
  Font control_font;
  Font edit_font;
  Font meter_font;
  Font text_font;
  Font clock_font;

  XFontStruct *info_font_info;
  XFontStruct *info_big_font_info;
  XFontStruct *comp_font_info;
  XFontStruct *control_font_info;
  XFontStruct *edit_font_info;
  XFontStruct *meter_font_info;
  XFontStruct *text_font_info;
  XFontStruct *clock_font_info;

  int meter_indicator_width;

  int component_window_height;
  int component_window_width;

  int info_window_width;
  int info_window_height;
  int info_window_vertical_padding;
  int info_window_horizontal_padding;

  int info_big_window_width;
  int info_big_window_height;
  int info_big_window_vertical_padding;
  int info_big_window_horizontal_padding;

  int meter_window_height;
  int meter_window_width;
  int meter_info_window_entries;

  int control_window_height;
  int control_window_width;

  int text_window_height;
  int text_window_width;

  int border_width;
  int x_center;
  int y_center;
  int x;
  int y;
  int height;
  int width;

  GC the_gc;
  GC meter_or_log_indicator_gc;
  GC clock_erase_gc;
  GC clock_draw_gc;
  GC line_gc;
  GC back_gc;
  GC xor_gc;


  unsigned long clock_color;
  unsigned long edit_color;
  unsigned long back_color;
  unsigned long text_color;
  unsigned long fore_color;
  unsigned long component_color[30];	/* Maximum number of different
     types of components unfortunately hardwired. */
  GC component_back_gc[30];	/* To use to clear parts of infowindows. */
  GC route_gc[16][3];
  unsigned long route_color[16][3];

  short delta;

  /** Has it ever been run? */
  int never_ran;
  /**** Single stepping or not? */
  int single_step;
  /** Is the simulator iconified? */
  int iconified;
  /* What is the display like? */
  int reverse_video;		/* this is only relevant to
				   monochrome displays. */
} ENVIRONMENT;

extern ENVIRONMENT the_environment;
extern KEY_BINDING user_bindings;



/* for debug X lib -- tlin@cis, 2/28/96 */
#define SEEXNOW XFlush(the_environment.the_display)



#endif   /* SIMX_H   */



