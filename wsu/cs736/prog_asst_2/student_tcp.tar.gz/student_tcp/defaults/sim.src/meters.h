/* meters.h,v 1.0 1993/10/21 19:12:05 NIST golmie */
/*
 *
 * $Log:	meters.h,v $
 * Revision 3.0  97/01/31  00:26:39  goyal
 * Final Revision
 * 
 * Revision 2.0  97/01/31  00:25:27  goyal
 * Final Revision
 * 
 * Revision 1.2  97/01/22  15:09:05  goyal
 * Given to students
 * 
 * Revision 1.1  97/01/18  17:14:05  goyal
 * Initial revision
 * 
 * Revision 2.1  1996/05/28 05:57:31  tlin
 * bump to v 2.1; before tcl/tk conversion
 *
 * Revision 0.1  1996/05/27 22:51:35  tlin
 * test
 *
 * Revision 0.0  96/04/26  15:34:27  goyal
 * Lab1
 * 
 * Revision 1.0  96/04/24  15:01:53  shivkuma
 * Lab 1
 * 
 * Revision 1.1  96/04/22  00:00:03  shivkuma
 * Version Before Putting in User-Friendly names
 * 
 * Revision 0.0  96/02/21  00:44:02  goyal
 * Initial Revision
 * 
 *
 *
 */

#ifndef METERS_H
#define METERS_H
/* SHIV : cleaned up for CISE */

#include "simx.h"

#define METER_HEIGHT 30
#define METER_WIDTH 150
#define METER_X 500
#define METER_Y 500


typedef struct _METERTYPE
{
  char meter_name[30];
  int meter_type;
  double height;
  double width;

} METERTYPE;

extern METERTYPE meter_types[];

typedef struct {
  char string[30];
} METERINFOSTRING;


typedef struct {
  int time_increment;
  int data_head;
  int data_tail;
  int data_length;
  int time;
  double *data_array;
  int num_classes;
  PARAM **param_array;
  char *name_array;
} MULTI_METER;

typedef struct {
  int time_increment;
  int data_head;
  int data_tail;
  int data_length;
  tick_t time;			/* Time when last line drawn on screen */
  tick_t last_update_time;	/* Time that update() was last called */
  double update_value;
  double *data_array;
  double counter;
  double divider;
} TH;

typedef struct {
  int data_head;	/* oldest sample */
  int data_samples;	/* max number of samples retained */
  int data_obs;		/* current number of samples */
  double *data_array;   /* table of samples */
/* SHIV : CISE : unsure */ int	 *hist_array;    /* table of cells */
  double hist_min;      /* least sample value recorded */
  double hist_max;	/* greatest sample value recorded */
/* SHIV : CISE : unsure */  double hist_intrvl;	/* (hist_max - hist_min) / hist_cells */
/* SHIV : CISE : unsure */  int    hist_cells;    /* how many cells */
} HISTO_METER;

typedef struct  {
  Param *parameter;
  COMPONENT *scomponent;
  TH *th;
  HISTO_METER *hist;
  Window meter_window;
  Window info_window;
  char name[20];
  short display_name;
  short display_scale;
  int x,y;
  int width, height;
  int info_x, info_y;
  int info_width, info_height;
  short logging;
  short type;
} METER;

#endif   /* METERS_H   */
