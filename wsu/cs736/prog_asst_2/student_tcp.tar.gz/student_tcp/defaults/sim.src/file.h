
/* 
   $Log:	file.h,v $
 * Revision 3.0  97/01/31  00:26:26  goyal
 * Final Revision
 * 
 * Revision 2.0  97/01/31  00:25:13  goyal
 * Final Revision
 * 
 * Revision 1.2  97/01/22  15:08:05  goyal
 * Given to students
 * 
 * Revision 1.1  97/01/18  17:13:59  goyal
 * Initial revision
 * 
   Revision 4.0  1996/08/23 20:02:27  tlin
   bump to mickey mouse version

   Revision 3.0  1996/05/30 14:40:54  tlin
   bump to 3.0; before Tk adition

   Revision 1.2  1996/05/29 17:21:55  tlin
   read_world()

   Revision 1.1  1996/05/29 16:50:32  tlin
   Initial revision


   */
/*   cise project -- tlin@cis                      */


int save_world(list *clist, char *filename, list *route_table);
int save_snapshot(list *clist, char *filename, list *route_table);
list *read_world(char *name);
