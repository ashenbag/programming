/* controls.h,v 1.0 1993/10/21 19:11:05 NIST */
/*
 *
 * $Log:	controls.h,v $
 * Revision 3.0  97/01/31  00:26:21  goyal
 * Final Revision
 * 
 * Revision 2.0  97/01/31  00:25:08  goyal
 * Final Revision
 * 
 * Revision 1.3  97/01/31  00:16:34  goyal
 * Final Revision
 * 
 * Revision 1.2  97/01/22  15:07:53  goyal
 * Given to students
 * 
 * Revision 1.1  97/01/18  17:13:57  goyal
 * Initial revision
 * 
 * Revision 2.1  1996/05/28 05:57:31  tlin
 * bump to v 2.1; before tcl/tk conversion
 *
 * Revision 0.1  1996/05/27 22:51:15  tlin
 * test
 *
 * Revision 0.0  96/04/26  15:34:18  goyal
 * Lab1
 * 
 * Revision 1.0  96/04/24  15:01:32  shivkuma
 * Lab 1
 * 
 * Revision 1.1  96/04/21  23:59:55  shivkuma
 * Version Before Putting in User-Friendly names
 * 
 * Revision 0.0  96/02/21  00:43:56  goyal
 * Initial Revision
 * 
 *
 *
 */




#ifndef CONTROLS_H
#define CONTROLS_H
/* SHIV : cleaned up for CISE */

#include "simx1.h"

#define X_INITIAL 780
#define Y_INITIAL 269

#ifdef ENABLE_INPUT
    enum {NOTHING=0, QUIT, START, SAVE, LOAD, SNAP, UPDATE, RUN_STEP, 
	  DESTROY, PRINT, DELAY};
#else
    enum {NOTHING=0, QUIT, START, LOAD, RUN_STEP, DELAY, HELP};
#endif

typedef struct _CONTROL {
  Window window;
  int wposition;
  int hposition;
  char name[30];
  char background_color[30];
} CONTROL;
#endif   /* CONTROLS_H   */
