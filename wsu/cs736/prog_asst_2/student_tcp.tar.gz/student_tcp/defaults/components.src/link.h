/* $Log:	link.h,v $
 * Revision 1.3  97/01/22  15:08:58  goyal
 * Given to students
 * 
 * Revision 1.2  97/01/19  23:44:59  goyal
 * *** empty log message ***
 * 
 * Revision 1.1  97/01/18  17:11:42  goyal
 * Initial revision
 * 
 * Revision 1.5  1996/12/20 06:08:40  goyal
 * TCP lab
 *
 * Revision 1.4  96/08/29  10:21:14  shivkuma
 * More Mickey mouse fixes
 * 
 * Revision 1.3  96/08/27  14:01:57  shivkuma
 * More bugs in Mickey fixed
 * 
 * Revision 1.2  96/08/26  16:13:20  shivkuma
 * Added mickey mouse to lab3
 * 
 * Revision 1.1  96/07/12  20:51:28  tlin
 * Initial revision
 * 
 * Revision 1.0  96/04/24  14:54:44  shivkuma
 * Lab 1
 *  */

#ifndef LINK_H
#define LINK_H

#include "q.h"
#include "eventdefs.h"
#include "component.h"
#include "log.h"
#include "comptypes.h"
#include "pdu.h"
#include "event.h"
#include "route.h"
#include "subr.h"
#include "sim_tk.h"


typedef struct _LINKConnectiont{
   struct _LINKConnectiont *cn_next, *cn_prev;
   short         cn_class;
   short         cn_type;
   char          cn_name[40];    /* Name of component (appears on screen) */
     PFP           cn_action;      /* Main function of component.  */
  XComponent    *cn_picture;     /* Graphics object that displays this thing */
  list          *cn_neighbors;  /* List of neighbors of this thing */

   /* Parameters-- data that will be displayed on screen */
   short         cn_menu_up;     /* If true, then the text window is up */
   short         cn_big_menu;     /* not used */
  queue         *cn_params;     /* Variable-length queue of parameters */

  int           cn_iq_length;    /* get the current input q length here */
  int           cn_iq_limit;    /* get the current input q length here */


  int           cn_flash;
  Param         *cn_Name;

  Param		*cn_delay;
  Param		*cn_err;

  double 	cn_todrop; /* Number of packets to be dropped  */
  double	cn_last_drop_time;
			   

} LINKConnectiont;

caddr_t link_action(Component *src, LINKConnectiont *cn, int type, PDU_TYPE *pdu, caddr_t arg);

#endif
  
