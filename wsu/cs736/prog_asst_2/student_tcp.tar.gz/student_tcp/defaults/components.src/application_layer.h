/* $Log:	application_layer.h,v $
 * Revision 1.3  97/01/22  15:08:53  goyal
 * Given to students
 * 
 * Revision 1.2  97/01/19  23:44:46  goyal
 * *** empty log message ***
 * 
 * Revision 1.1  97/01/18  17:11:36  goyal
 * Initial revision
 * 
 * Revision 1.4  1996/12/26 10:43:03  goyal
 * *** empty log message ***
 *
 * Revision 1.3  96/08/27  14:01:50  shivkuma
 * More bugs in Mickey fixed
 * 
 * Revision 1.2  96/08/26  15:57:45  shivkuma
 * Added mickey mouse to lab3
 * 
 * Revision 1.1  96/07/12  20:51:28  tlin
 * Initial revision
 * 
 * Revision 0.0  96/04/26  15:37:27  goyal
 * Lab1
 * 
 * Revision 0.0  96/04/26  15:30:47  goyal
 * Lab1
 * 
 * Revision 0.0  96/04/26  15:01:43  goyal
 * Lab1
 * 
 * Revision 0.0  96/04/26  14:57:33  goyal
 * Lab1
 * 
 * Revision 0.0  96/04/26  14:54:22  goyal
 * Lab1
 * 
 * Revision 0.0  96/04/26  14:53:46  goyal
 * Lab1
 * 
 * Revision 0.0  96/04/26  14:46:11  goyal
 * Lab1
 * 
 * Revision 0.0  96/04/26  14:44:13  goyal
 * Lab1
 * 
 * Revision 1.1  96/04/25  16:18:55  tlin
 * LOAD fixed
 * 
 * Revision 1.0  96/04/24  14:54:40  shivkuma
 * Lab 1
 *  */

#ifndef APPLICATION_LAYER_H
#define APPPLICATION_LAYER_H

#include "q.h"
#include "eventdefs.h"
#include "log.h"
#include "component.h"
#include "comptypes.h"
#include "event.h"
#include "route.h"
#include "pdu.h"
#include "subr.h"
/*#include "action.h"*/
#include "sim_tk.h"
#include <stdio.h>


typedef struct _APPConnectiont{
   struct _APPConnectiont *cn_next, *cn_prev;
   short         cn_class;
   short         cn_type;
   char          cn_name[40];    /* Name of component (appears on screen) */
  PFP           cn_action;      /* Main function of component.  */
  XComponent    *cn_picture;     /* Graphics object that displays this thing */
  list          *cn_neighbors;  /* List of neighbors of this thing */

   /* Parameters-- data that will be displayed on screen */
   short         cn_menu_up;     /* If true, then the text window is up */
  short         cn_big_menu;     /* not used */
  queue         *cn_params;     /* Variable-length queue of parameters */

  int		j1,j2;          /* junk values : DONT remove this : 
				   I cast this structure somewhere -SHIV */

  int           cn_flash;
  Param         *cn_Name;     /* Turn packet logging on & off */
  Param         *cn_bit_rate;
  Param         *cn_start_time;
  Param         *cn_trans_size;
  Param 	*cn_pkts_recvd;
  Param 	*cn_stop_time;
  Param		*cn_destination;

  int cn_num_sent;
  int stop;
  char *stalled_data;
  int cn_sending;
     
} APPConnectiont;


#define MY_SEND_A_PDU (Evtype)(EV_CLASS_PRIVATE | 1) 


#endif
  
