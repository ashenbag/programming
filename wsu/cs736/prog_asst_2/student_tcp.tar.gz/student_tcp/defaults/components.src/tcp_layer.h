#ifndef TCP_LAYER_H
#define TCP_LAYER_H

#include "route.h"
#include "q.h"
#include "pdu.h"
#include "action.h"
#include "string.h"
#include <stdlib.h>


caddr_t tcp_layer_action();


typedef struct _TCPConnectiont {
  struct _TCPConnectiont *tcp_next, *tcp_prev;
  short         tcp_class;
  short         tcp_type;
  char          tcp_name[40];    /* Name of component (appears on screen) */
  PFP           tcp_action;      /* Main function of component.  */
  XComponent    *tcp_picture;     /* Graphics object that displays this thing */
  list          *tcp_neighbors;  /* List of neighbors of this thing */

  /* Parameters-- data that will be displayed on screen */
  short         tcp_menu_up;     /* If true, then the text window is up */
  short         tcp_big_menu;     /* not used */
  queue         *tcp_params;     /* Variable-length queue of parameters */

  int           tcp_iq_length;    /* get the current input q length here */
  int           tcp_iq_limit;    /* get the current input q length here */

  int           tcp_flash;

  

   /* Parameters-- data that will be logged */
  Param         *tcp_Name;
  Param         *tcp_buf_size;
  Param         *tcp_sndseq_log;  /* Flag whether sender sequence number
                                   logging is to be activated */
  Param         *tcp_ackseq_log;  /* flag whether ACK seq #'s logging */
  Param         *tcp_rcvseq_log;  /* Flag whether receiver sequence number
                                   logging is to be activated */
  Param         *tcp_cwnd_log;    /* Logging connection window size in octets. */

  Param 	*tcp_option_mask;   /* TCP option mask */
  Param 	*tcp_granularity_param;/* dum1: Timer granularity value in ms */
  Param 	*tcp_wndscale;       /* dum2: TCP scale option value */






  Param         *tcp_max_seg_size;/*length of packets exchanged*/
  Param         *tcp_my_rcv_wnd; /* Size of MY receiver window in octets. */
  Param         *tcp_pr_rcv_wnd; /* Size of PEER'S receiver window in octets. */

  Param         *tcp_rtt;   /* round trip time */
  Param         *tcp_rto;   /* Retransmission timeout interval */
  Param         *tcp_rto_val; /* retransmission timeout interval (current)
                                with exponential backoff) */



  /* TCP Connection data */
  int  tcp_my_addr;      /* My address */
  int  tcp_peer_addr;    /* Address of peer TCP */

  int  tcp_snd_wnd;      /* Size of offered window (bytes) */
  int  tcp_snd_cwnd;     /* Size of sender's congestion window (bytes) */
  int  tcp_snd_ssthresh; /* Slow start threshold (bytes) */

  int  tcp_snd_max;      /* Max sequence number sent so far (bytes) */
  int  tcp_snd_nxt;      /* Sequence number of next segment to be sent (bytes) */
  int  tcp_snd_una;      /* Sequence number of first unacknowledged segment */
  int  tcp_rcv_nxt;      /* Sequence number of next expected segment */

  int  tcp_ack_flag;     /* 1 if the segment contains an ack, 0 otherwise */
  int  tcp_mss;          /* Maximum segment size */

  queue  *tcp_send_queue;     /* Queue of application's packets to be sent to dlc */
                              /* This is accessible by the following functions */
                              /* Insert_pdu_into_send_queue(); */
                              /* Remove_pdu_from_send_queue(); */
  int    tcp_send_queue_size; /* Size in bytes of the above queue */

  queue  *tcp_reseq_queue;    /* Queue of out_of_order packets received */
                              /* from the dlc waiting to be processed */
                              /* This is accessible by the following functions */
                              /* Insert_pdu_into_reseq_queue(); */
  int 		tcp_dupacks;  /* duplicate acks count : for fast Rexmit */
  tick_t 	tcp_t_rtt;    /* 1 if segment is being timed, 0 otherwise */
  int 		tcp_rtseq;    /* which segment is being timed : 
                                   rtseq variable in stevens */

  int  tcp_snd_offset;        /* How many bytes sent by application so far */
  int  tcp_state;             /* The state of the TCP connection */
  int		tcp_snd_scale;   /* Window Scale factor : max = 14 */
  /* Performance calculation parameters */
  long          tcp_srtt;          /* Smoothed RTT average */
  long          tcp_rttvar;          /* Scaled variance of RTT */
  tick_t 	tcp_granularity; /* rexmit timer granularity */
  int 		tcp_t_timer;     /* Rexmit timer */
  int           tcp_active_retrans_timer; /* State of retransmission timer (on,off) */
  tick_t 	tcp_next_packet_time;   /* When to send next packet  */

  int 		tcp_my_real_rcv_wnd; /* Revision: 4.0  : for scaling */

  unsigned      tcp_trans_num;   /* Total number of transmissions */
  unsigned      tcp_max_seq_sent; /* Highest seq number xmitted.
                                    (this is different than snd_nxt) */



   int          my_trace_no;
   int		tcp_dropped_bytes;
   int	        tcp_dumped;
   int 		tcp_ooq_bytes;

   int          tcp_simple_connection;

} TCPConnectiont;

#define TCP_LAYER_ENTITY_TYPE TCPConnectiont
#define GENERIC_LAYER_ENTITY_TYPE Component

typedef struct  send_tag {

        int     offset;
        int     len;
        
  /* char data[DATASIZE]; */
        PDU_TYPE  pdu;

}       send_buf;

#define MAXBUFFER 65535

/* TCP_BUFFER_TYPE is a blackbox: Managed by InsertPDU, RemovePDU, and
	       FreeBuffers */
     
typedef struct{

    int buffer_index; /*  Index of last PDU in buffer */
    int buffers_available; /* Number of buffers available */
    int snd_una_shadow;  /* Shadows the snd_una variable in the
			    (possibly larger) buffer */
    PDU_TYPE buf[MAXBUFFER]; /* Retransmission buffer */
} TCP_BUFFER_TYPE; 



/* Revision: 4.0  : option masks set */ 

#define FAST_REXMIT	0x1
#define SET_WND_SCALE	0x4

#define SET_TCP_TRACE	0x10

#define fast_rexmit(tcpcn)    (((tcpcn)->tcp_option_mask->u.i)  & FAST_REXMIT) 
#define set_wnd_scale(tcpcn)    (((tcpcn)->tcp_option_mask->u.i)  & SET_WND_SCALE) 
#define set_tcp_trace(tcpcn)    (((tcpcn)->tcp_option_mask->u.i)  & SET_TCP_TRACE) 





#endif /* TCP_LAYER_H */
