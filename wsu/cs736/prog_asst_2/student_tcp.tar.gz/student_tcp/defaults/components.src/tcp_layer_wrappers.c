#include "cisePort.h"
#include "sim.h"
#include "component.h"
#include "comptypes.h"
#include "list.h"
#include "eventdefs.h"
#include "main.h"
#include "route_activity.h"
#include "tcp_layer.h"



#define GRANULARITY_TIMER (Evtype)(EV_CLASS_PRIVATE | 1)

#define DEFAULT_TIMEOUT 1200000  /* 1200 ms = 1200000 us */
#define ESTABLISHED 0
#define TCP_MAXWIN 65535
#define DEFAULT_SGMT_SZ 512
#define TCP_MAX_SCALED_CWND 1073725440
#define TCP_MAX_WINSHIFT 14
#define MAX_INTEGER 2147483647

#ifdef DEBUG
extern Log debug_log;
#endif

extern int doXstuff;

static int      update_rto(), trim_pkt(), 
                process_insequence_pkt(), process_outofsequence_pkt(),
                send_pdu_to_application(), send_pdu_to_datalink(); 

static int      process_ack(), reset_dupacks(), free_acked_data(), 
                     slow_start(), misc_functions_on_ack(), fast_rexmit_code(),
                     send_new_data(), output_pkt(), 
                     Insert_pdu_into_send_queue(), 
                     Get_pdu_from_send_queue();

static int          Insert_pdu_into_resequence_queue(),
                    Process_packets_from_resequence_queue
                                 (TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu);

int                  Calculate_max_send_queue_offset();



static caddr_t tcp_reset(),tcp_create(),tcp_neighbor(), tcp_start(),
               tcp_uneighbor(),tcp_route(),tcp_hops(), tcp_open(),
               tcp_close_snd(),tcp_close_rcv(),
               tcp_layer_receive(),tcp_retrans_timeout(),
               tcp_granularity_timer(), tcp_process_syn();


caddr_t
tcp_layer_action(src,tcp_layer,type,pdu,arg)
      Component *src;
      TCP_LAYER_ENTITY_TYPE *tcp_layer;
      int type;
      PDU_TYPE *pdu;
      caddr_t arg;

{

     caddr_t result = NULL;
     dbg_set_level(DBG_ERR);
     
     if (tcp_layer) 
       dprintf(30,"TCP layer Event %x  %s %d \n",type,tcp_layer->tcp_name,tcp_layer->tcp_class);

    switch (type)  {
      
     case EV_RESET:                               
      result=tcp_reset(tcp_layer);
      break;

     case EV_CREATE:                             
      result=tcp_create((char *)arg);
      break; 

     case EV_DEL:                               
      comp_delete((Component *)tcp_layer);
      result = (caddr_t) tcp_layer;
      break;

     case EV_NEIGHBOR:                         
      result = tcp_neighbor(tcp_layer, (Component *)arg);
      break;

     case EV_UNEIGHBOR:                       
      result = tcp_uneighbor(tcp_layer, (Component *)arg);
      break;

     case EV_LEGAL_NEXT_HOPS:                
      result = tcp_hops(tcp_layer);
      break;

     case EV_MAKE_ROUTE:                    
      result = tcp_route(tcp_layer, (list *)arg);
      break;
     
     case EV_UPDATE_ROUTE_ACTIVITY:
       update_routes(src,(Component *)tcp_layer);              
      result =  (caddr_t) tcp_layer;

     case EV_START:                        
      result = tcp_start(tcp_layer);
      break;

     case GRANULARITY_TIMER:              
      result = tcp_granularity_timer((Component *) tcp_layer);
               ev_enqueue(GRANULARITY_TIMER, (Component *)tcp_layer, 
                      (Component *)tcp_layer, ev_now()+tcp_layer->tcp_granularity, 
                      tcp_layer_action, (PDU_TYPE *)NULL,(caddr_t)NULL); 
      break;

     case EV_RECEIVE:
      result = tcp_layer_receive(tcp_layer,src,pdu);
      break;

     case EV_SYN:
      result = tcp_process_syn(tcp_layer, (Component *) src, (char *) arg); 
      break;

   default:
#ifdef DEBUG
      dbg_write(debug_log, DBG_INFO, (Component *)tcp_layer,
                "got unexpected event of type %x", type);
#endif
      break;
    }

  return(result);
}


/*****************************************/
int
get_number_from_string(char *p)
{

while(!isdigit(*p)) p++;

return atoi(p);
}

static caddr_t 
tcp_process_syn(TCP_LAYER_ENTITY_TYPE *ttcp_layer, 
               GENERIC_LAYER_ENTITY_TYPE *co, char *dest)
{


        ttcp_layer->tcp_peer_addr = atoi(dest);
	ttcp_layer->tcp_my_addr = 
             get_number_from_string(co->co_name);

	return ( (caddr_t) ttcp_layer);

}



static caddr_t tcp_start(TCP_LAYER_ENTITY_TYPE *tcp_layer)
{
   Neighbor *n;


   /* Start immediately in the established state */
   tcp_layer->tcp_state = ESTABLISHED;

   tcp_layer->tcp_mss = pval(tcp_layer, tcp_max_seg_size)->u.i;
   tcp_layer->tcp_granularity = 
           USECS_TO_TICKS(tcp_layer->tcp_granularity_param->u.d*1000.0); 
   tcp_layer->tcp_t_rtt = 0;  /* counts number of ticks for ack to return */
   tcp_layer->tcp_t_timer = 0; /* Rexmit timer */
   ev_enqueue(GRANULARITY_TIMER, (Component *) tcp_layer, (Component *)tcp_layer,
		   ev_now()+tcp_layer->tcp_granularity, tcp_layer_action, 
		   NULL,(caddr_t)NULL); 


   for (n=(Neighbor *)tcp_layer->tcp_neighbors->l_head;n;n=n->n_next) {	
         if (n->n_c->co_class == APP_CLASS) break;		
   }					
				
   ev_enqueue(EV_READY,(Component *)  tcp_layer, (Component *) n->n_c, ev_now(),
           n->n_c->co_action, NULL,(caddr_t) NULL);

    return ((caddr_t)tcp_layer);
}



/********************************************************/

static caddr_t
tcp_reset(TCP_LAYER_ENTITY_TYPE *tcp_layer)
{
   TCP_LAYER_ENTITY_TYPE *co;
   int scale,win;


   tcp_layer->tcp_snd_offset = 0;

   /* Empty the packet queue */
    if  (!pval(tcp_layer, tcp_max_seg_size)->u.i)  {
        pval(tcp_layer, tcp_max_seg_size)->u.i =  512;
        log_param(tcp_layer, pval(tcp_layer, tcp_max_seg_size));
    }
    tcp_layer->tcp_mss = pval(tcp_layer, tcp_max_seg_size)->u.i;

    if  (!pval(tcp_layer, tcp_my_rcv_wnd)->u.i)  {
        pval(tcp_layer, tcp_my_rcv_wnd)->u.i = 65535;
        log_param(tcp_layer, pval(tcp_layer, tcp_my_rcv_wnd));
    }

    while (q_deq(tcp_layer->tcp_send_queue)) ;
    tcp_layer->tcp_send_queue_size = 0;
    while (q_deq(tcp_layer->tcp_reseq_queue)) ;
     
    pupdatei(tcp_layer, tcp_rtt, 0);

    pupdated(tcp_layer, tcp_rto, (3 * (tcp_layer->tcp_granularity_param->u.d)*1000)); 
    pupdatei(tcp_layer, tcp_rto_val, (int) 
                       (3 * (tcp_layer->tcp_granularity_param->u.d)*1000));

   pupdatei(tcp_layer, tcp_pr_rcv_wnd, 0);

   pupdatei(tcp_layer, tcp_pr_rcv_wnd, pval(tcp_layer, tcp_my_rcv_wnd)->u.i);

       /* Revision: 4.0  : Setting window scale is the right way for > 64K windows */

   if (set_wnd_scale(tcp_layer)) {

	int t;

	tcp_layer->tcp_snd_scale = 
		Minm(((int)pval(tcp_layer, tcp_wndscale)->u.d), TCP_MAX_WINSHIFT);

		/* Revision: 4.0  : for my side */

	t = Minm(((int)pval(tcp_layer, tcp_wndscale)->u.d), TCP_MAX_WINSHIFT);
	tcp_layer->tcp_my_real_rcv_wnd = tcp_layer->tcp_my_rcv_wnd->u.i << t;
   } else { 
	int t;
	
	tcp_layer->tcp_snd_scale = 
		Minm(((int)pval(tcp_layer, tcp_wndscale)->u.d), TCP_MAX_WINSHIFT);

	/* Revision: 4.0  : for my side */

	t = Minm(((int)pval(tcp_layer, tcp_wndscale)->u.d), TCP_MAX_WINSHIFT);
	tcp_layer->tcp_my_real_rcv_wnd = tcp_layer->tcp_my_rcv_wnd->u.i << t;


   }

   tcp_layer->tcp_snd_wnd = 
               pval(tcp_layer, tcp_pr_rcv_wnd)->u.i << tcp_layer->tcp_snd_scale;
      
   tcp_layer->tcp_snd_cwnd = pval(tcp_layer, tcp_max_seg_size)->u.i;
   
   pupdatei(tcp_layer, tcp_cwnd_log,tcp_layer->tcp_snd_cwnd);

   tcp_layer->tcp_snd_max = tcp_layer->tcp_snd_nxt = tcp_layer->tcp_snd_una = 0;
   tcp_layer->tcp_rcv_nxt = 0;

   /* Keep ssthresh a multiple of the segment size */
   win = tcp_layer->tcp_snd_wnd / (pval(tcp_layer, tcp_max_seg_size)->u.i) ;
  
   if (win < 2) win = 2;
   tcp_layer->tcp_snd_ssthresh = win * pval(tcp_layer, tcp_max_seg_size)->u.i;

   tcp_layer->tcp_trans_num = 0;
   tcp_layer->tcp_max_seq_sent = 0;
   tcp_layer->tcp_active_retrans_timer = FALSE;
   tcp_layer->tcp_srtt = tcp_layer->tcp_rttvar = 0;
   tcp_layer->tcp_next_packet_time = 0;
   tcp_layer->tcp_dupacks = 0;
   tcp_layer->tcp_rtseq = -1; 
   tcp_layer->tcp_t_rtt = 0;
   tcp_layer->tcp_t_timer = 0; 
   tcp_layer->tcp_dropped_bytes = 0;
   tcp_layer->tcp_ooq_bytes = 0;
   tcp_layer->tcp_dumped = 0;

#ifdef DEBUG
  dbg_write(debug_log, DBG_INFO, (Component *)tcp_layer, "reset");
#endif
  return((caddr_t)tcp_layer);
}

/***********************************************************************/
static caddr_t
tcp_create(char *name)
{
     TCP_LAYER_ENTITY_TYPE *newtcp_layer;

     /* Memory for the component structure. */
     newtcp_layer = (TCP_LAYER_ENTITY_TYPE *) sim_malloc(sizeof(TCP_LAYER_ENTITY_TYPE));

     /* First things first-- copy name into the new structure. */
     strncpy(newtcp_layer->tcp_name, name, 40);

     /* have to create a neighbor list */
      newtcp_layer->tcp_neighbors = l_create();
      /* Initialize the parameters */
      newtcp_layer->tcp_params = q_create();

      newtcp_layer->tcp_class = TCP_CLASS;
      newtcp_layer->tcp_type = TCP_LAYER_TYPE;
      newtcp_layer->tcp_action = tcp_layer_action;
      newtcp_layer->tcp_menu_up = FALSE;
      newtcp_layer->tcp_flash = 0;

      newtcp_layer->tcp_Name = param_init((Component *)newtcp_layer, "Name",
                 (PFD)NULL, make_name_text, make_short_name_text,
                 param_input_name,
                 0, DisplayMask | InputMask | CanHaveLogMask, 0.0);

     newtcp_layer->tcp_buf_size = param_init((Component *)newtcp_layer,
                "Buffer size (Bytes)",
                (PFD)NULL, make_int_text, make_short_int_text,
                param_input_int, 0,
                DisplayMask | InputMask, 0.0);

      newtcp_layer->tcp_sndseq_log = param_init((Component *)newtcp_layer,
                "Sender sequence number logging",
                 int_calc, make_int_text, make_short_int_text,
		 (PFI)NULL, TIME_HISTORY, DisplayMask | CanHaveMeterMask 
		 | CanHaveLogMask, 0.0);


      newtcp_layer->tcp_ackseq_log = param_init((Component *)newtcp_layer,
                "Sender ACK sequence number logging",
               int_calc, make_int_text, make_short_int_text,
		 (PFI)NULL, TIME_HISTORY, DisplayMask | CanHaveMeterMask 
		 | CanHaveLogMask, 0.0);

      newtcp_layer->tcp_rcvseq_log = param_init((Component *)newtcp_layer,
                "Receiver sequence number logging",
               int_calc, make_int_text, make_short_int_text,
		 (PFI)NULL, TIME_HISTORY, DisplayMask | CanHaveMeterMask 
		 | CanHaveLogMask, 0.0);

      newtcp_layer->tcp_max_seg_size = param_init((Component *)newtcp_layer,
                "Max segment size (octets)",
                (PFD)NULL, make_int_text, make_short_int_text,
                param_input_int, 0,
                DisplayMask | InputMask | CanHaveLogMask, 0.0);
      newtcp_layer->tcp_max_seg_size->u.i = DEFAULT_SGMT_SZ;

      newtcp_layer->tcp_my_rcv_wnd = param_init((Component *)newtcp_layer,
                "My Receive Window Size (octets)",
                (PFD)NULL, make_int_text, make_short_int_text,
                param_input_int, 0,
                DisplayMask | InputMask | CanHaveLogMask, 0.0);

      newtcp_layer->tcp_my_rcv_wnd->u.i = TCP_MAXWIN; 

      newtcp_layer->tcp_pr_rcv_wnd = param_init((Component *)newtcp_layer,
                "Peer Receive Window Size (octets)",
                (PFD)NULL, make_int_text, make_short_int_text,
                param_input_int, 0,
                DisplayMask | CanHaveLogMask, 0.0);
      pval(newtcp_layer, tcp_pr_rcv_wnd)->u.i = 0;

      newtcp_layer->tcp_cwnd_log = param_init((Component *)newtcp_layer,
                "Congestion Window Size logging",
                 int_calc, make_int_text, make_short_int_text,
		 (PFI)NULL, TIME_HISTORY, DisplayMask | CanHaveMeterMask 
		 | CanHaveLogMask, 0.0);

      newtcp_layer->tcp_rtt = param_init((Component *)newtcp_layer,
                "RTT (uSecs)",
                int_calc, make_int_text, make_short_int_text,
                (PFI)NULL, TIME_HISTORY,
                DisplayMask | CanHaveMeterMask | CanHaveLogMask, 0.0);
      pval(newtcp_layer, tcp_rtt)->u.i = 0;

      newtcp_layer->tcp_rto = param_init((Component *)newtcp_layer,
                "RTO (uSecs)",
                double_calc, make_double_text, make_short_double_text,
                (PFI)NULL, TIME_HISTORY,
                DisplayMask |  CanHaveMeterMask | CanHaveLogMask, 0.0);
      pval(newtcp_layer, tcp_rto)->u.d = (double)DEFAULT_TIMEOUT;

      newtcp_layer->tcp_rto_val = param_init((Component *)newtcp_layer,
                "RTO Current",
                int_calc, make_int_text, make_short_int_text,
                (PFI)NULL, TIME_HISTORY,
                DisplayMask | CanHaveMeterMask | CanHaveLogMask, 0.0);
      pval(newtcp_layer, tcp_rto_val)->u.i = DEFAULT_TIMEOUT;

      newtcp_layer->tcp_option_mask = param_init((Component *)newtcp_layer,
                    "TCP Option Mask",
                    (PFD)NULL,(PFP)make_int_text,(PFP)make_short_int_text,
                    param_input_int,
                    0,DisplayMask | InputMask, 0);
     pval(newtcp_layer, tcp_option_mask)->u.i = 0;

     newtcp_layer->tcp_granularity_param = param_init((Component *)newtcp_layer,
            "TCP Timer Granularity (ms)",
             (PFD)NULL, (PFP)make_double_text, (PFP)make_short_double_text,
             param_input_double, 0,
             DisplayMask | InputMask, 0.0);

      /* Timer granularity : default = 0.1 ms*/
      pval(newtcp_layer,tcp_granularity_param)->u.d  = 0.05;  

      newtcp_layer->tcp_wndscale = param_init((Component *)newtcp_layer,
            "TCP Window Scale",
             (PFD)NULL, make_double_text, make_short_double_text,
             param_input_double, 0,
             DisplayMask | InputMask, 0.0);

      newtcp_layer->tcp_wndscale->u.d  = 0;  

      /* Initialize the input queue of packets */
      newtcp_layer->tcp_send_queue = q_create();

      /* Initialize the reseq queue of packets */
      newtcp_layer->tcp_reseq_queue = q_create();


   
      return((caddr_t)newtcp_layer);
}

    

/*************************************************************************/
static caddr_t
tcp_neighbor(register TCP_LAYER_ENTITY_TYPE *tcp_layer, register Component *c) 
{
    register Neighbor *n;

    if (!(n=add_neighbor((Component*)tcp_layer,c,2,2,APP_CLASS,DLC_CLASS)))
        return ((caddr_t)NULL);

    return ((caddr_t)n);
}
/*****************************************/
static caddr_t
tcp_uneighbor(register TCP_LAYER_ENTITY_TYPE *tcp_layer, register Component *c) 
{
   return ((caddr_t)remove_neighbor((Component *)tcp_layer,c));
}

/******************************************/

static caddr_t
tcp_hops(register TCP_LAYER_ENTITY_TYPE *tcp_layer, list *l) 
{
   register list *nlist;
   register Neighbor *n;
   register Component *c;


   c = (Component *) (l->l_tail->le_data);

  /* Make an empty list */
   nlist=l_create();

   /* Put all neighbors that are apps, dlcs in the list */
    for (n= (Neighbor *) tcp_layer->tcp_neighbors->l_head;n;n=n->n_next)
         if (n->n_c != c && ((c->co_class == APP_CLASS)
	       || ((c->co_class == DLC_CLASS) && n->n_c->co_class == APP_CLASS)))
            l_addt(nlist,(caddr_t)n->n_c);

#ifdef DEBUG
       dbg_write(debug_log,DBG_INFO,(Component *)tcp_layer,
                  "returning list of legal nex hops");
#endif

return ((caddr_t)nlist);
}

/************************************************************************/
static caddr_t
tcp_route(register TCP_LAYER_ENTITY_TYPE *tcp_layer, list *route_list)
{
#ifdef NOTDEF

Socket *so;
Param *p;
Component *this_component;
Component *other_component;
Neighbor *n1;
Neighbor *n2;

        
         if ((TCP_LAYER_ENTITY_TYPE *)route_list->l_head->le_data == tcp_layer)
          {
      
            /* I am the head, my other socket is the tail */
            /* Get the other socket
               Short explanation:
           l->l_tail->le_data = pointer to connection at other end of route.
           I am calling the action routine of the component pointed
           to by the tail of the list.  I then cast the result to a Socket  */
            

           so = (Socket *)
                 ((*(((Component *)route_list->l_tail->le_data)->co_action))
                     (tcp_layer, route_list->l_tail->le_data, EV_GET_MY_SOCKET,
                      NULL, -1,(caddr_t)NULL));

    
      } else if ((TCP_LAYER_ENTITY_TYPE *)route_list->l_tail->le_data == tcp_layer)  {
    

        /* I'm the tail, the other half is the head. */

        so = (Socket *)
             ((*(((Component *)route_list->l_head->le_data)->co_action))
                     (tcp_layer, route_list->l_head->le_data, EV_GET_MY_SOCKET,
                      NULL, -1,(caddr_t)NULL));

      }
     




      p=param_init((Component *)tcp_layer,"Other End Connection :               ",
                      int_calc,make_int_text,make_short_int_text,
                      (PFI)NULL,0,DisplayMask | CanHaveLogMask,0.0);


      if ((((Component *)route_list->l_head->le_data)->co_name[3] !=
              tcp_layer->tcp_name[3]) ||
             (((Component *)route_list->l_head->le_data)->co_name[2] !=
              tcp_layer->tcp_name[2]) ||
              (((Component *)route_list->l_head->le_data)->co_name[1] !=
              tcp_layer->tcp_name[1]) ||
              (((Component *)route_list->l_head->le_data)->co_name[0] !=
              tcp_layer->tcp_name[0]) )

            strcat(p->p_name,((Component *)route_list->l_head->le_data)->
                              co_name);
        else strcat(p->p_name,((Component *)route_list->l_tail->le_data)->
                               co_name);

         tcp_layer->tcp_vpi=VPI;

        /* Fixing simple connection: a  bte and two end nodes */

	 /* _todo_: remove this junk about simple connection and
	    the stupid string matching above */
        this_component = (Component *)route_list->l_head->le_data;
	other_component = (Component *)route_list->l_tail->le_data ;


        n1= (Neighbor *)this_component->co_neighbors->l_head;
        n2= (Neighbor *)other_component->co_neighbors->l_head;


         if (n1->n_c->co_name[3] == n2->n_c->co_name[3])
            tcp_layer->tcp_simple_connection=1;



           return ((caddr_t)tcp_layer); /* return something non-null */

#endif  /* NOTDEF */
}

/* CISE todo : include these for graceful exit */
/*********************************************************************/
static caddr_t
tcp_close_rcv(tcp_layer)
  TCP_LAYER_ENTITY_TYPE *tcp_layer;
{
#ifdef NOTDEF  
   /* Close the receiver connection. Basicaly, ack receiver's buffers */
   if(tcp_layer->tcp_output_queue){
        q_elt *elt;

        for(elt = tcp_layer->tcp_output_queue->q_head; elt; elt = elt->qe_next){

/* Revision: 4.0  : avoid some events */
		free((char *)elt->qe_data);

/*          ev_enqueue(EV_RCV_OK, tcp_layer, tcp_layer, ev_now(),
                     tcp_layer_action , NULL,
                     (caddr_t)elt->qe_data);
*/
        }
      }

#ifdef DEBUG
      dbg_write(debug_log, DBG_INFO, tcp_layer, "receiving TCP closed ");
#endif

#endif
  return ((caddr_t)tcp_layer);

}
/* CISE todo : include these for graceful exit */
/**************************************************************************/
static caddr_t
tcp_close_snd(tcp_layer)
  TCP_LAYER_ENTITY_TYPE *tcp_layer;
{

#ifdef NOTDEF
   /* Close the sender side of the connection. */


#ifdef DEBUG
      dbg_write(debug_log, DBG_INFO, tcp_layer, "sending TCP closed ");
#endif

   return ((caddr_t)tcp_layer);

#endif
}


static int
send_pdu_to_datalink( TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pkt)
{

     Neighbor *n;

     for (n=(Neighbor *)tcp_layer->tcp_neighbors->l_head;n;n=n->n_next) {	
         if (n->n_c->co_class == DLC_CLASS) break;		
     }					

     /* CISE todo: make bit rate and header length into a parameter */
     if (tcp_layer->tcp_next_packet_time == 0) 
                  tcp_layer->tcp_next_packet_time = ev_now();
     if (tcp_layer->tcp_next_packet_time < ev_now()) 
                  tcp_layer->tcp_next_packet_time = ev_now();

     if (pkt->u.t_pdu.tcp_hdr.pk_len == 0) pkt->color = ACK_COLOR;
     else if (tcp_layer->tcp_snd_nxt < tcp_layer->tcp_snd_max) pkt->color = TCP_COLOR;
     else  pkt->color = SENDING_COLOR;
							   
     /*
     if (M.doX) 				             
         route_activity((Component *)tcp_layer, (Component *) n->n_c, 10, SENDING_COLOR, 0); 
	 */
     ev_enqueue(EV_RECEIVE, (Component *) tcp_layer,(Component *)  n->n_c, 
               tcp_layer->tcp_next_packet_time+10, n->n_c->co_action, 
               (PDU_TYPE *) pkt,(caddr_t) NULL);

     tcp_layer->tcp_next_packet_time  += 
                    USECS_TO_TICKS(((20*8.0)/(155.52))) +
                    USECS_TO_TICKS(((pkt->u.t_pdu.tcp_hdr.pk_len*8.0)/(155.52)));

}
     
/*********************************************************************/
static int
send_pdu_to_application(TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu)
{
  T_PDU_TYPE *pkt = &(pdu->u.t_pdu);
  int rcvd_bytes_num = pkt->tcp_hdr.pk_len;
  q_elt *elt;
  PDU_TYPE *pdu_to_application ;
  Neighbor *n;				


  if(pkt->tcp_hdr.pk_len > 0) { /* rcv next should be monotonic */
	                        /* so don't accept negative packet lengths */

	  pdu_to_application = (PDU_TYPE *) pdu_alloc(); 
	  pdu_to_application->type   = TYPE_IS_A_PDU;
	  pdu_to_application->color  = pdu->color;
	  bcopy((char *)&(pkt->a_pdu),
		(char *)&(pdu_to_application->u.a_pdu), A_PDU_SIZE);

	  for (n=(Neighbor *)tcp_layer->tcp_neighbors->l_head;n;n=n->n_next) {	
		  if (n->n_c->co_class == APP_CLASS)			
		       break;					
	  }						
	  /*
	  if (M.doX) 		
		 route_activity((Component *)tcp_layer, (Component *) n->n_c, 10, SENDING_COLOR, 0);  
		 */

	  ev_enqueue(EV_RECEIVE, (Component *)tcp_layer, (Component *) n->n_c, 
                               ev_now()+10, n->n_c->co_action, 
                               (PDU_TYPE *) pdu_to_application, (caddr_t)NULL);	
	  pdu_free(pdu);
  }

#ifdef DEBUG
        dbg_write(debug_log, DBG_INFO, tcp_layer,"processed MY_INPUT");
#endif
}

static int 
Insert_pdu_into_send_queue(TCP_LAYER_ENTITY_TYPE *tcp_layer, 
                            GENERIC_LAYER_ENTITY_TYPE *generic_layer_entity, 
                            PDU_TYPE *pdu)
{

            send_buf *tcp_snd_buffer;

            tcp_snd_buffer = (send_buf *) sim_malloc(sizeof(send_buf));
            tcp_snd_buffer->offset = tcp_layer->tcp_snd_offset;
            tcp_snd_buffer->len = pdu->u.a_pdu.len;
            tcp_layer->tcp_snd_offset += tcp_snd_buffer->len;

            tcp_snd_buffer->pdu.type = pdu->type;
            bcopy( (char *) & pdu->u.a_pdu, 
                   (char *) & (tcp_snd_buffer->pdu.u.a_pdu),
	           A_PDU_SIZE);

            q_addt(tcp_layer->tcp_send_queue, tcp_snd_buffer);
            tcp_layer->tcp_send_queue_size += pdu->u.a_pdu.len;
      
            if (tcp_layer->tcp_send_queue_size >= tcp_layer->tcp_snd_wnd) {
                     dprintf(30,"TCP %s sending busy to app %s %d>= %d \n",
                                tcp_layer->tcp_name,
                                generic_layer_entity->co_name,
                                tcp_layer->tcp_send_queue_size,
                                tcp_layer->tcp_snd_wnd);
                     ev_enqueue(EV_BUSY, (Component *) tcp_layer, 
                                (Component *) generic_layer_entity , ev_now(),
                               generic_layer_entity->co_action, NULL,(caddr_t) NULL);
           }



}
static int 
Get_pdu_from_send_queue(TCP_LAYER_ENTITY_TYPE *tcp_layer, 
                            PDU_TYPE *pkt,
			    int offset)
{
 q_elt *q_e;
        for (q_e = tcp_layer->tcp_send_queue->q_head; 
                       ((send_buf *)q_e->qe_data)->offset != offset 
             ; q_e = q_e->qe_next);
         bcopy( (char *) & (((send_buf *) q_e->qe_data)->pdu).u.a_pdu , 
              (char *) & (pkt->u.t_pdu.a_pdu),
              A_PDU_SIZE);
}

int Calculate_max_send_queue_offset(TCP_LAYER_ENTITY_TYPE *tcp_layer) {

int max_buf_offset;

  max_buf_offset = tcp_layer->tcp_snd_nxt - 1;
  if (tcp_layer->tcp_send_queue->q_tail)
	   max_buf_offset =
		((send_buf *)(tcp_layer->tcp_send_queue->q_tail->qe_data))->offset +
		 ((send_buf *)(tcp_layer->tcp_send_queue->q_tail->qe_data))->len-1;

return (max_buf_offset);

}


static int Log_pkt_stats(TCP_LAYER_ENTITY_TYPE *tcp_layer,
                         PDU_TYPE *pkt) 
{

     tick_t ticks;
    /* Statistics: Increment the transmission number and update 
      the retrans percentage */

    int offset = pkt->u.t_pdu.tcp_hdr.pk_seq ;
    int len = pkt->u.t_pdu.tcp_hdr.pk_len ;

    /* Don't time pkt if ACK, time pkt again @ 0 time */
    if(ev_now() == 0) tcp_layer->tcp_t_rtt = 0;  

    if (pkt->u.t_pdu.tcp_hdr.pk_len > 0)  {
             /* This counter kept only for retrans % computation.  */
	     tcp_layer->tcp_max_seq_sent = Maxm(tcp_layer->tcp_max_seq_sent, 
                                               offset + len - 1);
	     tcp_layer->tcp_trans_num += pkt->u.t_pdu.tcp_hdr.pk_len;

            if (M.doX) 
                cise_sn_event(tcp_layer->tcp_my_addr, "sending", 
                                ev_now(),pkt->u.t_pdu.tcp_hdr.pk_seq);
		pupdatei(tcp_layer, tcp_sndseq_log,pkt->u.t_pdu.tcp_hdr.pk_seq);
    } else {
      /*
            if (M.doX) 
                  cise_sn_event(tcp_layer->tcp_my_addr, "ack", 
                                ev_now(),tcp_layer->tcp_rcv_nxt);
      */
    }

    if (!tcp_layer->tcp_active_retrans_timer && 
	tcp_layer->tcp_snd_nxt != tcp_layer->tcp_snd_una &&
	pkt->u.t_pdu.tcp_hdr.pk_len > 0) {
	     ticks = 0;

	     pupdatei(tcp_layer, tcp_rto_val,pval(tcp_layer, tcp_rto)->u.d);

	     tcp_layer->tcp_t_timer = (int) ceil(USECS_TO_TICKS(
                                            pval(tcp_layer, tcp_rto_val)->u.i)
                                                 / tcp_layer->tcp_granularity);
	     tcp_layer->tcp_active_retrans_timer = TRUE;
     }
}

/*********************************************************************/
static int
update_rto(TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu)
{
int SRTT,tmp_rto;
long Delta;
  T_PDU_TYPE *pkt = &(pdu->u.t_pdu);

/* Recalculate RTO if clock info in packet */
/* Algorithm is outlined in Van Jacobson's paper at SIGCOMM '88 */

 if ( (tcp_layer->tcp_t_rtt &&  pkt->tcp_hdr.pk_ack > tcp_layer->tcp_rtseq) ) { 

	/* Revision: 4.0  : ignore timestamps */

	SRTT = tcp_layer->tcp_t_rtt;
	pval(tcp_layer, tcp_rtt)->u.i =
		TICKS_TO_USECS(tcp_layer->tcp_granularity*SRTT);
	log_param(tcp_layer, pval(tcp_layer, tcp_rtt));
	/* set up initial SA (don't include dflt rto) */
	/* Revision: 4.0  : We maintain srtt differently with granularity
	   Following stevens code */

	if (tcp_layer->tcp_srtt == 0) { /* (Re)initialization */
		tcp_layer->tcp_srtt = SRTT << 3; /* TCP_RTT_SHIFT */
		tcp_layer->tcp_rttvar = SRTT << 1;  /* TCP_RTTVAR_SHIFT -1 */
	} else {
		/* Revision: 4.0  : lifted from Stevens book */
		Delta = SRTT - 1 - (tcp_layer->tcp_srtt >> 3); /* TCP_RTT_SHIFT */
		if ((tcp_layer->tcp_srtt += Delta) <= 0)
			tcp_layer->tcp_srtt = 1;
		if(Delta < 0) Delta = -Delta;
		Delta -= (tcp_layer->tcp_rttvar >> 2); /* TCP_RTTVAR_SHIFT */
		if ((tcp_layer->tcp_rttvar += Delta) <= 0)
			tcp_layer->tcp_rttvar = 1;
	}

	tcp_layer->tcp_t_rtt = 0;
	/* Revision: 4.0  : _todo_: modify to integrate non-timestamped RTT */
	/* Stevens sets t_rxtshift : index to backoff array to 0 : 
	   I ignore it */
	/* _todo_: Maximum = 128 ticks, affected by resolution !! */
	/* Note => have to restrict it in the backoff algo too */

	tmp_rto = (tcp_layer->tcp_srtt >> 3) + tcp_layer->tcp_rttvar;
	tmp_rto = (tmp_rto < 2) ? 2 : tmp_rto; /* min = 2 ticks */
	tmp_rto = (tmp_rto > 128) ? 128 : tmp_rto; /* max = 128 ticks */
		  
	pval(tcp_layer, tcp_rto)->u.d = 
		TICKS_TO_USECS((double) (tcp_layer->tcp_granularity*tmp_rto));
	log_param(tcp_layer, pval(tcp_layer, tcp_rto));
	pupdatei(tcp_layer, tcp_rto_val,pval(tcp_layer, tcp_rto)->u.d);

} /* pk_ack > rtseq && tcp_t_rtt */

return 0;
}
/*********************************************************************/
static int
trim_pkt(TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu)
{
  T_PDU_TYPE *pkt = &(pdu->u.t_pdu);
 int *ppkt_len = &(pkt->tcp_hdr.pk_len);
 int *ppkt_seq = &(pkt->tcp_hdr.pk_seq);
 int old_pkt_length=0;

  if (M.doX)
         cise_sn_event(tcp_layer->tcp_my_addr, "receiving", ev_now(), 
                        pdu->u.t_pdu.tcp_hdr.pk_seq);
  pupdatei(tcp_layer, tcp_rcvseq_log,pdu->u.t_pdu.tcp_hdr.pk_seq);
/* Trim off portions of packet that are outside the window */
/* Discard duplicate packets */
  if (*ppkt_len >= 0) old_pkt_length = *ppkt_len;
  if (*ppkt_seq < tcp_layer->tcp_rcv_nxt) {
    /* CISE : currently we receive complete packets or nothing
              because SAR is not implemented
     */
          (*ppkt_len) = 0;
	  (*ppkt_seq) = tcp_layer->tcp_rcv_nxt;
    /*  Once SAR is implemented, replace the above 2 lines
        with the following two lines:
	  (*ppkt_len) -= tcp_layer->tcp_rcv_nxt - (*ppkt_seq);
	  (*ppkt_seq) = tcp_layer->tcp_rcv_nxt;
    */
  }



/* more trimming based on rcv_window size */
/* Revision: 4.0  : should used the scaled (real) window here */
  if ((*ppkt_seq) + (*ppkt_len)-1
                        >= tcp_layer->tcp_rcv_nxt + tcp_layer->tcp_my_real_rcv_wnd) {
	  
    /* CISE : currently we receive complete packets or nothing
              because SAR is not implemented
     */
          (*ppkt_len) = 0;
    /*  Once SAR is implemented, replace the above line
        with the following line:
	  (*ppkt_len) -= (((*ppkt_seq) + (*ppkt_len)) -
			  (tcp_layer->tcp_rcv_nxt + tcp_layer->tcp_my_real_rcv_wnd));
    */
  }

 if((*ppkt_len) < 0) (*ppkt_len) = 0;

 if (old_pkt_length > 0)
	 tcp_layer->tcp_dropped_bytes += (old_pkt_length - (*ppkt_len));


  if (M.doX) 
   cise_sn_event(tcp_layer->tcp_my_addr, "ack", ev_now(),pkt->tcp_hdr.pk_ack);
  pupdatei(tcp_layer, tcp_ackseq_log,pkt->tcp_hdr.pk_ack);


return 0;
}

static int
Insert_pdu_into_resequence_queue(TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu)
{
  q_elt *qe;
  T_PDU_TYPE *pkt = &(pdu->u.t_pdu);

  /* Buffer pkt in correct position in reseq queue */
  /*  Free_pkt = FALSE; */
  qe = (q_elt *) NULL;

  /* Revision: 4.0  : counting OOQ bytes */
  tcp_layer->tcp_ooq_bytes += pkt->tcp_hdr.pk_len; 


  if (tcp_layer->tcp_reseq_queue->q_head) {
     if (pkt->tcp_hdr.pk_seq < ((PDU_TYPE *) 
           (tcp_layer->tcp_reseq_queue->q_head->qe_data))->u.t_pdu.tcp_hdr.pk_seq)
	q_addh(tcp_layer->tcp_reseq_queue, pdu);
     else {
	  for(qe = (q_elt *) tcp_layer->tcp_reseq_queue->q_head ; 
                                         qe->qe_next; qe = qe->qe_next)
	      if (((PDU_TYPE *) qe->qe_data)->u.t_pdu.tcp_hdr.pk_seq 
                  <= pkt->tcp_hdr.pk_seq && pkt->tcp_hdr.pk_seq < 
                     ((PDU_TYPE *) qe->qe_next->qe_data)->u.t_pdu.tcp_hdr.pk_seq)
		 break;
	  q_adda(tcp_layer->tcp_reseq_queue, qe, pdu) ;
     }
  } else
	  q_addt(tcp_layer->tcp_reseq_queue,pdu) ;

}

static int 
Process_packets_from_resequence_queue(TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu)
{

  q_elt *qe;
  PDU_TYPE *pk;

  for ( qe = (q_elt *) tcp_layer->tcp_reseq_queue->q_head; qe; qe = qe->qe_next ) {

      if ((pk = (PDU_TYPE *) qe->qe_data)->u.t_pdu.tcp_hdr.pk_seq > 
                                tcp_layer->tcp_rcv_nxt)  
         break;

      /* what 's left is pk_seq <= rcv_nxt */
      /* Trim off portions of packet that are outside the window */
      /* Revision: 4.0  : counting OOQ bytes */
      /* CISE : SAR is not implemented. We don't trim yet */
      /*        If sending is done right then pk_seq should
                never be strictly less than rcv_nxt */
      if (pk->u.t_pdu.tcp_hdr.pk_seq < tcp_layer->tcp_rcv_nxt) 
	printf("Error: trimming error 1 \n");

      tcp_layer->tcp_ooq_bytes -= pk->u.t_pdu.tcp_hdr.pk_len;
      pk->u.t_pdu.tcp_hdr.pk_len -= tcp_layer->tcp_rcv_nxt - 
                                       pk->u.t_pdu.tcp_hdr.pk_seq;
      pk->u.t_pdu.tcp_hdr.pk_seq = tcp_layer->tcp_rcv_nxt;

      /* All we care about is extra data to be delivered */
      if (pk->u.t_pdu.tcp_hdr.pk_len > 0) {
	          pk = (PDU_TYPE *) q_deq(tcp_layer->tcp_reseq_queue);
                  dprintf(30,"send_pdu_to application (2) from reseq queue\n");
		  tcp_layer->tcp_rcv_nxt += pk->u.t_pdu.tcp_hdr.pk_len;
		  send_pdu_to_application(tcp_layer, pk);
      }


  }

}

int update_cwnd(TCP_LAYER_ENTITY_TYPE *tcp_layer, int value)
{

  tcp_layer->tcp_snd_cwnd = value;
  if (M.doX)
       cise_ss_event(tcp_layer->tcp_my_addr, "sending", ev_now(),
                 tcp_layer->tcp_snd_cwnd);
  pupdatei(tcp_layer, tcp_cwnd_log,tcp_layer->tcp_snd_cwnd);


}

int timer_backoff(TCP_LAYER_ENTITY_TYPE *tcp_layer) {
   pupdatei(tcp_layer, tcp_rto_val,pval(tcp_layer, tcp_rto_val)->u.i * 2);
                                                /* Double retrans timeout */
   tcp_layer->tcp_active_retrans_timer = TRUE;
   tcp_layer->tcp_t_timer = (int) ceil(USECS_TO_TICKS(pval(tcp_layer, 
                                   tcp_rto_val)->u.i) / tcp_layer->tcp_granularity);
}

/*********************************************************************/
static int
free_acked_data(TCP_LAYER_ENTITY_TYPE *tcp_layer, int nbytes)
{
  int acked_bytes_num = nbytes;
  q_elt *elt;
  Neighbor *n;

  /* Acknowledged data is removed from imaginary queue */
  /* _todo_ : check why : Send an OK to the user if a buffer has been fully acked */
  for(elt = tcp_layer->tcp_send_queue->q_head; elt; elt = elt->qe_next) {
	  if(acked_bytes_num == 0) break;
	  if(acked_bytes_num < ((send_buf *)elt->qe_data)->len) {
		  ((send_buf *)elt->qe_data)->len -= acked_bytes_num;
		  ((send_buf *)elt->qe_data)->offset += acked_bytes_num;
		  acked_bytes_num = 0;
		  break;
	  } else {
		  acked_bytes_num -= ((send_buf *)elt->qe_data)->len;
		  tcp_layer->tcp_send_queue_size -= ((send_buf *)elt->qe_data)->len;
		   free((char *)((send_buf *)elt->qe_data)); 
		  q_deq(tcp_layer->tcp_send_queue);
	 }
  }
  if (tcp_layer->tcp_send_queue_size < tcp_layer->tcp_snd_wnd) {

     for (n=(Neighbor *)tcp_layer->tcp_neighbors->l_head;n;
		      n=n->n_next) {	
	   if (n->n_c->co_class == APP_CLASS) break;
     }					
     ev_enqueue (EV_READY, (Component *) tcp_layer,(Component *)  n->n_c, ev_now(),
		   n->n_c->co_action, NULL,(caddr_t) NULL);
}


return 0;
}

/*********************************************************************/
static int
misc_functions_on_ack(TCP_LAYER_ENTITY_TYPE *tcp_layer)
{


  /* Reset retrans timer by dequeuing the timeout event from the event queue*/
  tcp_layer->tcp_t_timer = 0;

  tcp_layer->tcp_active_retrans_timer = FALSE;

  /* If the retransmission queue is not empty, set the retransmission
     timer by enqueuing a timeout event */
  /* Revision: 4.0  : TCP code uses snd_max instead of snd_nxt here ... */

  if  (tcp_layer->tcp_snd_una < tcp_layer->tcp_snd_max) {
	pupdatei(tcp_layer, tcp_rto_val, pval(tcp_layer, tcp_rto)->u.d);

	/* Macro expression in pupdatei argument above replaces:
	   (unsigned)(pval(tcp_layer, tcp_rto)->u.d/(double)USECS_PER_TICK)); */
		tcp_layer->tcp_t_timer = (int)
                ceil(USECS_TO_TICKS(pval(tcp_layer, tcp_rto_val)->u.i) / 
                                         tcp_layer->tcp_granularity);
		tcp_layer->tcp_active_retrans_timer = TRUE;      
  }


return 0;
}

int shut_timer_off(TCP_LAYER_ENTITY_TYPE *tcp_layer)
{
	tcp_layer->tcp_t_timer = 0;
	tcp_layer->tcp_active_retrans_timer = FALSE;
	tcp_layer->tcp_t_rtt = 0; 
}


#define TCPFromApplication(src) ((src)->co_class == APP_CLASS)
#define TCPFromDatalink(src) ((src)->co_class == DLC_CLASS)

/* tcp_layer_for_student.c starts here */
/* Everything above this should be in tcp_layer_wrappers.c */

