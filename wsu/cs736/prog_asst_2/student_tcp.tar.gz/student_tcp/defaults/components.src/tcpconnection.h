#ifndef TCPCONNECTION_H
#define TCPCONNECTION_H


#include "sim.h"
#include "q.h"
#include "list.h"
#include "cell.h"
#include "component.h"



/**********************************************
  Variation of component structure for tcp connection.
*/

caddr_t tcpconnection_action();

typedef struct  send_tag {

        int     offset;
        int     len;

        }       send_buf;

typedef struct _TCPConnectiont{
   struct _TCPConnectiont *cn_next, *cn_prev;
   short         cn_class;
   short         cn_type;
  /* short         cn_abr;  */       /* CISE: ? */
   char          cn_name[40];    /* Name of component (appears on screen) */
   PFP           cn_action;      /* Main function of component.  */
   COMP_OBJECT   cn_picture;     /* Graphics object that displays this thing */
   list          *cn_neighbors;  /* List of neighbors of this thing */

   short         cn_menu_up;     /* If true, then the text window is up */
   queue         *cn_params;     /* Variable-length queue of parameters */
  /* int           cn_vpi; */    /* CISE */

    int		iq_length;      /* put any public information here */
    int		iq_limit;       /* used for int packet trains */

  int		j1,j2,j3;          /* junk values : DONT remove this : 
				   I cast this structure somewhere -SHIV */

   Param         *cn_template;   /* Template */
   
   /* Parameters-- data that will be displayed on screen */
  Param         *cn_buf_size;     /* User's send and receive buffer sizes */
  Param         *cn_ustate;        /* User's transmitter state = on, or off */
  Param         *cn_ustart_time; /* User's start time. If it is negative, 
                                  a random
                                  start time is generated over the interval
                                  specified in u->u_start_per */
  Param         *cn_start_per;    /* User's random start interval */
  Param         *cn_tot_trans_size; /* User's transmission size (bytes) */
  Param         *cn_trans_size;   /* Number of bytes to be sent */
  
  Param         *cn_pktlog;     /* Turn packet logging on & off */
  Param         *cn_sndseq_log;  /* Flag whether sender sequence number
                                   logging is to be activated */
  Param         *cn_ackseq_log;  /* flag whether ACK seq #'s logging */
  Param         *cn_rcvseq_log;  /* Flag whether receiver sequence number
                                   logging is to be activated */
  Param         *cn_delay;      /* usecs it takes to process a packet */
  Param         *cn_fuzz;       /* Variation in pkt process time (usec) */
  Param         *cn_open_time;   /* Tcp open time in msec */
  Param         *cn_close_time;  /* Tcp close time in msec */
  Param         *cn_busy;       /* Store (& display) my state */
  Param         *cn_processing_queue; /* Imaginary transmission queue 
                                         represented 
                                        by # pkts awaiting transmission */
  Param         *cn_max_seg_size;/*length of packets exchanged*/
  Param         *cn_my_rcv_wnd; /* Size of MY receiver window in octets. */
  Param         *cn_pr_rcv_wnd; /* Size of PEER'S receiver window in octets. */
  Param         *cn_cwnd_log; /* Logging connection window size in octets. */

  Param         *cn_rtt;   /* round trip time */
  Param         *cn_rto;   /* Retransmission timeout interval */
  Param         *cn_rto_val; /* retransmission timeout interval (current)
                                with exponential backoff) */
  Param         *cn_throughput; /*Connection throughput measured in pkts/usecs*/
  Param         *cn_retrans_percent; /* Percentage of retransmission */
  /*Param         *cn_color; *//* Integer-valued "flavor" of emitted packets */

  
  Param         *cn_cbr_vbr;
  Param         *cn_bit_rate;
  Param         *cn_burst_length;
  Param         *cn_int_bet_burst;
  Param         *cn_start_time;

/* Revision: 4.0  : option masks & dummies  */ 

  Param 	*cn_option_mask;   /* TCP option mask */
  
  Param 	*cn_dum1;       /* Timer granularity value in ms */
  Param 	*cn_dum2;       /* TCP scale option value */
  Param 	*cn_dum3;       /* TCP dummies to pass parameters */
  Param 	*cn_dum4;       /* TCP dummies to pass parameters */
  Param 	*cn_dum5;       /* TCP dummies to pass parameters */
  Param 	*cn_dum6;       /* TCP dummies to pass parameters */
  Param 	*cn_dum7;       /* TCP dummies to pass parameters */
  Param 	*cn_dum8;       /* TCP dummies to pass parameters */
  Param 	*cn_dum9;       /* TCP dummies to pass parameters */
  Param 	*cn_dum10;       /* TCP dummies to pass parameters */

  /* Private data */
  send_buf *    cn_snd_buffer;   /* Address of last buffer sent for transmission
                                   by the TCP */

  int           cn_snd_offset;   /* How many bytes sent so far */
   
  int           cn_state;       /* The state of the TCP connection */
  Socket        cn_me;          /* My socket-- (so_port = me, so_host =
                                   my host).  Here only so the EV_GET_SOCKET
                                   command can easily return a pointer
                                   to a socket.  */
  Socket        cn_other_half;  /* The other side of this connection */
  int           cn_id;          /* my connection id */
  Component     *cn_user;       /* The TCP's user */
  queue         *cn_input_queue;/* Queue for user's send buffer request*/
  int           cn_snd_wnd;     /* Size of sender's window in octets. */
  int           cn_snd_cwnd;    /* Size of sender's congestion window*/
/*  double        cn_snd_cwnd_d;  *//* Used in calc of cong window size */
/* Revision: 4.0  */
  int           cn_snd_max;     /* Max seq number sent : detect rexmits */
  int           cn_snd_nxt;     /* Sequence number of next data packet to
                                   be sent */
  int           cn_snd_una;     /* Sequence number of oldest unacknowledged
                                   data packet */
  int           cn_snd_wl1;     /* Pkt sequence number at last window update*/
  int           cn_snd_wl2;     /* Packet acknowledgement number at last window
                                   update */
  int           cn_snd_ssthresh;/* The exp-to-linear threshhold in SLOW START*/

   int		cn_snd_scale;  /* Scale factor : max = 14 */

  queue         *cn_reseq_queue;/* Queue of out_of_order packets waiting to be
                                   processed */
  queue         *cn_output_queue;/* Queue of user's receive receive buffers*/
  queue         *cn_cell_queue; /* Added when implementing the aal5 for tcp-ip
                                   and this to hold th incoming the cells
                                   before a packet could be reassembled */
  int           cn_rcv_queue;   /* Imaginary queue of bytes waiting to be
                                   delivered to user upon availability of
                                   receive buffers*/
  int           cn_rcv_nxt;     /* Sequence number of next expected data pkt */

  /* Performance calculation parameters */
  long           cn_srtt;          /* Smoothed RTT average */
  long           cn_rttvar;          /* Scaled variance of RTT */
  unsigned      cn_trans_num;   /* Total number of transmissions */
  unsigned      cn_max_seq_sent; /* Highest seq number xmitted.
                                    (this is different than snd_nxt) */
  int           cn_sent_acks;   /* Total number of acks sent */
  int           cn_active_retrans_timer;
                                /* State of retransmission timer (on,off) */
/* Revision: 4.0  */
   tick_t 	cn_next_packet_time; 
                                /* When to send next packet : not 
				 before the cells of the previous 
				 packet are sent ... */
   int 		cn_sample_rtt_now;  /* now is the time to sample rtt */
   int 		cn_dupacks; 	/* duplicate acks count : for fast Rexmit */
   tick_t 	cn_granularity; /* rexmit timer granularity */
   tick_t 	cn_t_rtt;    /* tick count : t_rtt variable in stevens */
   int 		cn_rtseq; 	/* which segment is being timed : rtseq variable in stevens */
   int 		cn_t_timer; /* Rexmit timer */

   int 		my_trace_no; 	/* Tracing facility */
   int		cn_dropped_bytes;
   int		cn_cells_dropped;
   int	        cn_dumped;
   int 		cn_ooq_bytes;
   int 		cn_my_real_rcv_wnd; /* Revision: 4.0  : for scaling */

  int           cn_flash;
  int           cn_simple_connection;
  int cn_num_sent;
  int cn_started;
}TCPConnectiont;

/* Revision: 4.0  : option masks set */ 

#define FAST_REXMIT	0x1
#define GRANULARITY	0x2
#define SET_WND_SCALE	0x4

#define SET_TCP_TRACE	0x10

#define fast_rexmit(tcpcn)    (((tcpcn)->cn_option_mask->u.i)  & FAST_REXMIT) 
#define granularity(tcpcn)    (((tcpcn)->cn_option_mask->u.i)  & GRANULARITY) 
#define set_wnd_scale(tcpcn)    (((tcpcn)->cn_option_mask->u.i)  & SET_WND_SCALE) 
#define set_tcp_trace(tcpcn)    (((tcpcn)->cn_option_mask->u.i)  & SET_TCP_TRACE) 





#endif /* TCPCONNECTION_H */
