/* 
   $Log:	action.h,v $
 * Revision 1.4  97/01/22  15:08:51  goyal
 * Given to students
 * 
 * Revision 1.3  97/01/19  23:44:40  goyal
 * *** empty log message ***
 * 
 * Revision 1.2  97/01/19  23:44:18  goyal
 * *** empty log message ***
 * 
 * Revision 1.1  97/01/18  17:11:33  goyal
 * Initial revision
 * 
   Revision 1.3  1996/12/26 10:43:03  goyal
   *** empty log message ***

   Revision 1.2  1996/12/22 02:34:59  goyal
   compiles

   Revision 1.1  1996/07/12 20:51:28  tlin
   Initial revision

   Revision 3.0  1996/05/30 14:42:17  tlin
   bump to 3.0; before Tk adition

   Revision 1.4  1996/05/30 13:57:28  tlin
   foo

   Revision 1.3  1996/05/30 10:48:22  tlin
   LINKConnectiont was defined in link.h

   Revision 1.2  1996/05/30 10:30:06  tlin
   foo

   Revision 1.1  1996/05/30 10:28:41  tlin
   Initial revision

   */

/*   cise project -- tlin@cis                      */


caddr_t application_layer_action(void *, void *, int, void *, caddr_t);
caddr_t tcp_layer_action        ();
caddr_t dlc_layer_action        ();
caddr_t physical_layer_action   ();
caddr_t link_action             ();

