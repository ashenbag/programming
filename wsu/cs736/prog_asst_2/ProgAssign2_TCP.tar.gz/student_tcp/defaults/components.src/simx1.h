/*
 *
 * $Log:	simx1.h,v $
 * Revision 3.0  97/01/31  00:26:52  goyal
 * Final Revision
 * 
 * Revision 2.0  97/01/31  00:25:41  goyal
 * Final Revision
 * 
 * Revision 1.2  97/01/22  15:09:23  goyal
 * Given to students
 * 
 * Revision 1.1  97/01/18  17:14:10  goyal
 * Initial revision
 * 
 * Revision 2.2  1996/05/29 00:49:38  tlin
 * move DisplayMask etc for p_flags to component.h
 *
 * Revision 2.1  1996/05/28 05:57:31  tlin
 * bump to v 2.1; before tcl/tk conversion
 *
 * Revision 0.1  1996/05/27 22:51:45  tlin
 * test
 *
 * Revision 0.0  96/04/26  15:34:33  goyal
 * Lab1
 * 
 * Revision 1.0  96/04/24  15:02:06  shivkuma
 * Lab 1
 * 
 * Revision 1.1  96/04/22  00:00:10  shivkuma
 * Version Before Putting in User-Friendly names
 * 
 * Revision 0.0  96/02/21  00:44:04  goyal
 * Initial Revision
 * 
 *
 *
 */

#ifndef SIMX1_H
#define SIMX1_H
/* simx1.h,v 1.0 1993/10/21 19:07:58 NIST */
/* SHIV : cleaned up for CISE */

/* This file includes the declarations for the graphics interface */

#include <X11/Xlib.h>
#include <X11/X.h>
#include <X11/Xutil.h>

#define COMP_WINDOW 0
#define INFO_WINDOW 1


/* Screen update variable */

int screen_update;

typedef caddr_t COMP_OBJECT;
typedef caddr_t GRAF_OBJECT; /* actually a meter*/

/* Shiv: Moved here from pdu.h (used in xinit.c, meters.c)  --- */
int packet_colors[64];
int num_packet_colors;

#endif   /* SIMX1_H */
