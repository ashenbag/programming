#ifndef CELL_H
#define CELL_H
/* cell.h,v 1.0 1993/10/21 19:12:12 NIST golmie*/

#include "sim.h"
#include "component.h"
/*************************************************************************/
/* Socket definition : 1-5-94 : TCP/IP implementation */

typedef struct _Socket{
Component *so_port,*so_host;
}Socket;

/*************************************************************************/
/* Additions 8-19-1993 */

typedef int VPI;
typedef int PTI;
typedef int AAL5_Trailer;


/* Packets used in simple connections; Not really used in the tcp-ip 
   implementation */
typedef struct _SimpleC_Pkt{
Component *pk_orgin;
tick_t pk_time;


} SimpleC_Pkt;

/* $Revision: 3.0 $ : compressing packet/cell data structures */
/* Packets used by TCP Connection */
typedef struct _TCP_Pkt{
/* Packet sequence number --used to identify packets. Should be unique
   over one run of the simulator */
int pk_seq;

/* Packet acknowledgment number  --used to identify acknowledged packets */
int pk_ack;

/* $Revision: 3.0 $ : compressing packet/cell data structures */
/* We will need this field, if we dynamically alter receiver window */
/* Packet window -- used to indicate the range of acceptable sequence numbers
  beyond the last packet succesfully received */
/* int pk_wnd; */

/* Additional fields for Purdue TCP, added invisibly at the end */
/* $Revision: 3.0 $ : compressing packet/cell data structures */
/* May be useful for timestamp option... But I am removing them for now */
/* int pk_recver_time;
   int pk_sender_time;
   */
/* $Revision: 3.0 $ : compressing packet/cell data structures */
/* int pk_cn_id; */

}TCP_Pkt;


/* $Revision: 3.0 $ */
/* Compressed format */

typedef struct _Mcell_Pkt{

tick_t timestamp;     /* timestamp : used for rtt calculation */

Rate_t rate;	     /* this is the reference rate for new rate computations */
                     /* we call it SCR */

/* $Revision: 3.0 $ */
/* Bit vector for BN, CI, NI, dir */
int bit_vector;

Rate_t ER;

}RMCell;

typedef struct _WebCell{
tick_t timestamp;  
}WebCell;

/* $Revision: 3.0 $ */
/* bit vector manipulation */

#define BN_bit 0x1
#define CI_bit 0x2
#define NI_bit 0x4
#define DIR_bit 0x8

#define init_bit_vect(cell) { (cell)->u.rm->bit_vector = 0; }

#define set_BN(cell) {((cell)->u.rm->bit_vector) |= BN_bit;}
#define test_BN(cell)(((cell)->u.rm->bit_vector) & BN_bit)

#define set_CI(cell) {((cell)->u.rm->bit_vector) |= CI_bit;}
#define test_CI(cell)(((cell)->u.rm->bit_vector) & CI_bit)

#define set_NI(cell) {((cell)->u.rm->bit_vector) |= NI_bit;}
#define test_NI(cell)(((cell)->u.rm->bit_vector) & NI_bit)

#define set_DIR(cell) {((cell)->u.rm->bit_vector) |= DIR_bit;}
#define test_DIR(cell)(((cell)->u.rm->bit_vector) & DIR_bit)

/***********************************************************************/

/* Main packet structure */
/* $Revision: 3.0 $ : compressing packet/cell data structures */

typedef struct _Packet {

/* $Revision: 3.0 $ : compressing packet/cell data structures */
/* Ultimate source and destination. Like sockets in TCP */
/* Socket pk_source_socket , pk_dest_socket; */

/* Length in bytes for use by tcp */
int pk_length;
AAL5_Trailer len;  /* length of pkt in cells for use by AAL5*/
     
/* Union of the various packet structures for different transport layers */
union pk_transport {
  SimpleC_Pkt s;
  TCP_Pkt t;
}u;
}Packet;

/* ----------------------------------- */
typedef struct _localPacket {

     struct _localPacket *pk_next;
     int pk_error_flag;

     int pk_length;

     /* No AAL5 trailer */ 
/* Union of the various packet structures for different transport layers */
     union localpk_transport {
	  SimpleC_Pkt s;
	  TCP_Pkt t;
     }u;
}localPacket;



/* ----------------------------------- */
/* Cell Structure */
typedef struct _Cell{
struct _Cell *cell_next;
VPI vpi;
PTI pti;

union cell_payload{
Packet *tcp_ip_info;
RMCell *rm;
WebCell *wb;
}u;

} Cell;


/* -------- $Revision: 3.0 $: PTI Formats ---------- */

/* Note that MARKED_CELL1 is not compatable with Mpegconnection : we'll
   worry about that later ... */

/* Revision: 4.0  : TCP/IP support :       
   Need a bit for AAL5 jobs
 */

/* ---- PTI MASKS ---- */
/* 0x1 reserved for tcp/aal5 (EOP = end of pkt) 
 * operation and EPD impln
 */
#define EOP	  0x1
#define EFCI_CELL 0x2
#define FRM_CELL  0x4
#define BRM_CELL  0x8
#define CLP       0x10

/* ---------- Closed Loop Bursty Model: See abrconnection2.c  -------- */
#define REQUEST_CELL 0x20
#define RESPONSE_CELL 0x40

/* --- First/last  cell in the req/resp --- */
#define FIRST_CELL_REQRESP 0x100
#define LAST_CELL_REQRESP 0x200

/* ---- First/last cell in the whole cycle --- */
#define FIRST_REQRESP 0x1000
#define LAST_REQRESP 0x2000

/* ---- For Plotting Purposes: The Bte stops logging when it knows
        that the source has stopped */
#define SOURCE_STOPPED 0x4000

#define UBR_CELL       0x8000

/* --- Negations --- */ 
#define NCLP      0xffef
#define NEG_FIRST_CELL_REQRESP 0xfeff
#define NEG_FIRST_REQRESP 0xefff
#define NEG_UBR_CELL 0x7fff

/* -------- Testing Macros ----- */

#define request_cell(cell) ((cell)->pti & REQUEST_CELL)
#define response_cell(cell) ((cell)->pti & RESPONSE_CELL)

#define last_cell_request(cell) ((cell)->pti & LAST_CELL_REQRESP)
#define last_cell_response(cell) ((cell)->pti & LAST_CELL_REQRESP)

#define first_cell_request(cell) ((cell)->pti & FIRST_CELL_REQRESP)
#define first_cell_response(cell) ((cell)->pti & FIRST_CELL_REQRESP)

#define last_req(cell) ((cell)->pti & LAST_REQRESP)
#define last_resp(cell) ((cell)->pti & LAST_REQRESP)

#define first_req(cell) ((cell)->pti & FIRST_REQRESP)
#define first_resp(cell) ((cell)->pti & FIRST_REQRESP)

#define ubr_cell(cell) ((cell)->pti & UBR_CELL)

#define fbrm_cell(cell) (((cell)->pti & FRM_CELL) || ((cell)->pti & FRM_CELL))

#define FORWARD 0
#define BACKWARD 1

/* End Additions */
/**************************************************************************/

#ifndef INLINE

void pk_free(),pk_free_all();
Packet *pk_alloc();

void localpk_free(),localpk_free_all();
localPacket *localpk_alloc();

void cell_free(), cell_free_all();
Cell *cell_alloc();

#endif



#ifdef _CELL_C_
/* ---- Being included in cell.c => define variables ---  */
/* Does not matter whether it is inline or not */

/* $Revision: 3.0 $ : Removed "static" from the following definitions */
Mempool *cell_mempool=NULL;
Mempool *pk_mempool = NULL;
Mempool *localpk_mempool = NULL;
int packet_colors[64];
int num_packet_colors;
int color_index;

unsigned numlpkts=0, numpkts=0, numcells=0;
unsigned maxlpkts=0, maxpkts=0, maxcells=0;
tick_t maxlpktstime=0, maxpktstime=0, maxcellstime=0;
unsigned totlpkts=0, totpkts=0, totcells=0;

#else
/* --- Being included in some other file --- */

#ifdef INLINE

/* We need the following extern declarations only if INLINE is used */
extern Mempool *cell_mempool;
extern Mempool *pk_mempool;
extern Mempool *localpk_mempool;
extern int packet_colors[];
extern int num_packet_colors;
extern int color_index;

/* $Revision: 3.0 $: making cell_alloc etc inline */
extern unsigned numlpkts, numpkts, numcells;
extern unsigned maxlpkts, maxpkts, maxcells;
extern tick_t maxlpktstime, maxpktstime, maxcellstime;
extern unsigned totlpkts, totpkts, totcells;

#endif

#endif


#ifdef INLINE
static inline
Packet * pk_alloc()
{
  register Packet *pk = (Packet *)mp_alloc(pk_mempool);

  numpkts++;   totpkts++;
  if(numpkts > maxpkts){
       maxpkts = numpkts;
       maxpktstime= ev_now();
  }
  if (color_index >= num_packet_colors)
     color_index = 0;
  return(pk);
}

static inline
void pk_free(pk)
     Packet *pk;
{
  mp_free(pk_mempool, (char *)pk);
  numpkts--;
}


static inline
localPacket *localpk_alloc()
{
  register localPacket *localpk = (localPacket *)mp_alloc(localpk_mempool);

  numlpkts++;   totlpkts++;
  if(numlpkts > maxlpkts){
       maxlpkts = numlpkts;
       maxlpktstime= ev_now();
  }

  return(localpk);
}

static inline
void localpk_free(localpk)
     localPacket *localpk;
{
  mp_free(localpk_mempool, (char *)localpk);
  numlpkts--;

}

static inline
Cell *cell_alloc()
{
register Cell *cell=(Cell*) mp_alloc(cell_mempool);

  numcells++;  totcells++;
  if(numcells > maxcells){
       maxcells = numcells;
       maxcellstime= ev_now();
  }
  
return(cell);
}

static inline
void cell_free(cell)
Cell *cell;
{
mp_free(cell_mempool,(char*)cell);
numcells--;
}
#endif

#endif   /* CELL_H   */







