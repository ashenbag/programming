
/* 
   $Log:	random.h,v $
 * Revision 3.0  97/01/31  00:26:44  goyal
 * Final Revision
 * 
 * Revision 2.0  97/01/31  00:25:32  goyal
 * Final Revision
 * 
 * Revision 1.2  97/01/22  15:09:13  goyal
 * Given to students
 * 
 * Revision 1.1  97/01/18  17:14:07  goyal
 * Initial revision
 * 
   Revision 4.0  1996/08/23 20:02:27  tlin
   bump to mickey mouse version

   Revision 3.0  1996/05/30 14:40:54  tlin
   bump to 3.0; before Tk adition

   Revision 1.2  1996/05/29 22:14:19  tlin
   rename srandom() -> Cise_random(); name conflict with standard lib

   Revision 1.1  1996/05/29 17:28:20  tlin
   Initial revision

   */

/*   cise project -- tlin@cis                      */

Cise_srandom(unsigned x);
