/* $Log:	physical_layer.h,v $
 * Revision 1.3  97/01/22  15:09:01  goyal
 * Given to students
 * 
 * Revision 1.2  97/01/19  23:45:05  goyal
 * *** empty log message ***
 * 
 * Revision 1.1  97/01/18  17:11:44  goyal
 * Initial revision
 * 
 * Revision 1.4  96/08/29  10:21:19  shivkuma
 * More Mickey mouse fixes
 * 
 * Revision 1.3  96/08/27  14:01:59  shivkuma
 * More bugs in Mickey fixed
 * 
 * Revision 1.2  96/08/26  16:37:13  shivkuma
 * Added mickey mouse to lab3
 * 
 * Revision 1.1  96/07/12  20:51:28  tlin
 * Initial revision
 * 
 * Revision 1.0  96/04/24  14:54:47  shivkuma
 * Lab 1
 * */

#ifndef PHYSICAL_LAYER_H
#define PHYSICAL_LAYER_H


#include "q.h"
#include "eventdefs.h"
#include "log.h"
#include "comptypes.h"
#include "event.h"
#include "route.h"
#include "subr.h"
#include "action.h"
#include "component.h"
#include "pdu.h"
#include "sim_tk.h"




caddr_t physical_layer_action();

typedef struct _PHYConnectiont{
   struct _PHYConnectiont *cn_next, *cn_prev;
   short         cn_class;
   short         cn_type;
   char          cn_name[40];    /* Name of component (appears on screen) */
  PFP           cn_action;      /* Main function of component.  */
  XComponent    *cn_picture;     /* Graphics object that displays this thing */
  list          *cn_neighbors;  /* List of neighbors of this thing */

   /* Parameters-- data that will be displayed on screen */
   short         cn_menu_up;     /* If true, then the text window is up */
   short         cn_big_menu;     /* not used */
  queue         *cn_params;     /* Variable-length queue of parameters */

  int           cn_iq_length;    /* get the current input q length here */
  int           cn_iq_limit;    /* get the current input q length here */


  int           cn_flash;
  Param         *cn_Name;

  list		*cn_crt;


} PHYConnectiont;


typedef struct cise_route_table {
int	dest;
int  	path_id;
char 	link[10];

} CRT;


#endif 
  
