/*
 *
 * $Log:	xtables.h,v $
 * Revision 3.0  97/01/31  00:26:57  goyal
 * Final Revision
 * 
 * Revision 2.0  97/01/31  00:25:46  goyal
 * Final Revision
 * 
 * Revision 1.2  97/01/22  15:09:32  goyal
 * Given to students
 * 
 * Revision 1.1  97/01/18  17:14:12  goyal
 * Initial revision
 * 
 * Revision 2.2  1996/05/28 05:57:31  tlin
 * bump to v 2.1; before tcl/tk conversion
 *
 * Revision 2.1  1996/05/28 05:54:01  tlin
 * bump to 2.1
 *
 * Revision 0.1  1996/05/27 22:51:49  tlin
 * test
 *
 * Revision 0.0  96/04/26  15:34:35  goyal
 * Lab1
 * 
 * Revision 1.0  96/04/24  15:02:11  shivkuma
 * Lab 1
 * 
 * Revision 1.1  96/04/22  00:00:11  shivkuma
 * Version Before Putting in User-Friendly names
 * 
 * Revision 0.0  96/02/21  00:44:06  goyal
 * Initial Revision
 * 
 *
 *
 */

/* xtables.h,v 1.0 1993/10/21 19:08:17 NIST */
#ifndef XTABLES_H
#define XTABLES_H
/* SHIV : cleaned up for CISE */

#include "simx1.h"

extern XContext comp_xtable; 
extern XContext control_xtable; 
extern XContext th_xtable;
extern XContext meter_xtable; 
extern XContext meterinfo_xtable;
#endif   /* XTABLES_H   */
