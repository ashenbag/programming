#ifndef PDU_H
#define PDU_H


#include <sys/types.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <sys/wait.h>

#include <signal.h>

#define INTSIZE   sizeof(int)
#define DATASIZE  512               /* maximum length          */
#define MAXNODES  20


/*************************************************************************/
/* Socket definition: TCP/IP implementation */

typedef struct _Socket {
  Component *so_port,*so_host;
} Socket;

/* The following are the types of messages communicated between 
 * physical layer & datalink layer, and client & server 
 */
enum datatypes { DATA, ERR };
enum boolean { NO, YES };

/* ---------- D_PDU Definition (Used in Go Back N Labs) ----- */
#define D_INFO 0
#define D_ACK  1
#define D_NAK  2

/* data unit between app. layer and datalink layer */
typedef struct {
     int  snode;                    /* source node address      */
     int  dnode;                    /* destination node address */
     int  len;
     char data[DATASIZE];           /* message                  */
} A_PDU_TYPE;
#define A_PDU_SIZE sizeof(A_PDU_TYPE)

typedef struct {
 
  int snode;
  int dnode;
  int pk_seq;
  int pk_ack;
  char pk_flags;
  int  pk_win;
  int  pk_checksum;   /* 0 => no error, non-zero => error, DLC layer may set this field */
  int pk_urp;
  int pk_len;
} TCP_HEADER_TYPE;
#define TCP_HEADER_SIZE sizeof(TCP_HEADER_TYPE)

typedef struct {

  TCP_HEADER_TYPE tcp_hdr;
  A_PDU_TYPE      a_pdu;

} T_PDU_TYPE;
#define T_PDU_SIZE sizeof(T_PDU_TYPE)
  

/* data unit between datalink layer and physical layer */
typedef struct {
     int               curr_node;   /* address of this node */
     int               next_node;   /* address of next node */

     /* ----------- Begin: New fields (Used in Go Back N Labs)  -------- */
     int               type;        /* One of D_INFO, D_ACK, D_NAK   */
     int               seq_number;  /* Sequence number of this D_PDU */
     int               ack_number;  /* Sequence number of ACK/NAK    */
     /* ----------- End: New fields (Used in Go Back N Labs) -------- */


     T_PDU_TYPE	       t_pdu;
     enum boolean      error;       /* YES if the packet is corrupted;
				       otherwise NO.            */
} D_PDU_TYPE;
#define D_PDU_SIZE sizeof(D_PDU_TYPE)

/* data unit between physical layers */
typedef struct {
     int               type;        /* ERR, DATA                */
     D_PDU_TYPE        d_pdu;
} PH_PDU_TYPE;
#define PH_PDU_SIZE sizeof(PH_PDU_TYPE)


/* ------ Values for the type field in PDU_TYPE ---- */
#define TYPE_IS_A_PDU 0
#define TYPE_IS_T_PDU 1
#define TYPE_IS_D_PDU 2
#define TYPE_IS_PH_PDU 3

typedef struct {
     union {
	  A_PDU_TYPE a_pdu;
	  T_PDU_TYPE t_pdu;
	  D_PDU_TYPE d_pdu;
	  PH_PDU_TYPE ph_pdu;
     } u; 

     int type;    /* One of TYPE_IS_A_PDU, TYPE_IS_D_PDU, TYPE_IS_PH_PDU */
     int color;

} PDU_TYPE;

#define PDU_SIZE sizeof(PDU_TYPE)

int pdu_init(); /* Initialize the pool of packets. Returns 0 for failure. */
PDU_TYPE *pdu_alloc(); /* Allocates a packet and returns a pointer
				thereto.  The packet is guaranteed to contain
				garbage. */
void pdu_free(PDU_TYPE *pdu);       /* Passed a packet pointer, frees it. */




/* End Additions */
/**************************************************************************/

#endif   /* PDU_H   */


