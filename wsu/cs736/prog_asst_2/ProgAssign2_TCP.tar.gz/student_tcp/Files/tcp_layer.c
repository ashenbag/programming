#include "tcp_layer_wrappers.c"



static caddr_t
tcp_layer_receive(TCP_LAYER_ENTITY_TYPE *tcp_layer, 
                  GENERIC_LAYER_ENTITY_TYPE *generic_layer_entity, 
                  PDU_TYPE *pdu)
/* You don't need to modify this function */
/* tcp_layer_receive: called when TCP receives a packet from application or datalink */
/* Processes the packet appropriately */
{


     if (TCPFromApplication(generic_layer_entity)) {

        Insert_pdu_into_send_queue(tcp_layer, generic_layer_entity, pdu);

        tcp_output(tcp_layer);    /* Try to output one or more packets */

        pdu_free(pdu);            /* Free the pdu */

 } else if (TCPFromDatalink(generic_layer_entity)) {

      tcp_input(tcp_layer, pdu);  /* tcp_input() processes the packet */

 } else { 
       printf("Don't know where the packet is from\n") ;
       fflush(stdout);
 }

}

static caddr_t
tcp_granularity_timer(TCP_LAYER_ENTITY_TYPE *tcp_layer)
/* You don't need to modify this function */
/* tcp_granularity_timer: Called every time the coarse granularity timer ticks */
/* The function checks to see if it has waited long enough for an ack */
/* If so, it calles tcp_retrans_timeout() */
{

     if (tcp_layer->tcp_t_rtt) tcp_layer->tcp_t_rtt++; 
                                           /* Increment the count if > 0 */
	                                   /* i.e., if some segment is being timed */

     if (tcp_layer->tcp_t_timer)  {
	 tcp_layer->tcp_t_timer -= 1;
	 if (!tcp_layer->tcp_t_timer)
	 tcp_retrans_timeout(tcp_layer);   /* retransmit a packet ... */
     }

     return ((caddr_t)tcp_layer);
}


tcp_output(TCP_LAYER_ENTITY_TYPE *tcp_layer)
/* tcp_output : called whenever a packet or an ACK can be sent */
/* The function figures out whether one or more packets can be sent */
/* and then calls the function output_pkt() which sends the packet */
{

   int max_to_send_offset; 
   int max_buf_offset; 


   /* Since we are not implementing piggybacked acknowledgements, */
   /* Check to see if the tcp_layer->tcp_ack_flag is set          */
   /* If so, then immediately send an ACK by calling              */
   /* output_pkt(tcp_layer, tcp_layer->tcp_snd_nxt, 0, 0);        */
   /*                                                             */
 
   /* Now see if data can be sent                                 */
   /* max_to_send_offset = sequence number of the maximum byte allowed to  */
   /*                      be sent by the window                           */
                           
   

  /* max_buf_offset = sequence number of the maximum byte that the application */
  /*                  has given me                                             */
  /*                  These bytes were stored in the send_queue                */


  /* Now, from the above,  calculate the sequence number of the maximum byte */
  /* that can be sent   */
  

  /* If tcp_snd_nxt is less than the above calculated value, then data is available */
  /* If data is not available, then just return */ 


  /* If data is available then calculate the length of the data that can be sent */
  /* This length is limited by the congestion window, the advertised window,     */
  /* the maximum segment size, and the amount of unacknowledged data that has    */
  /* already been sent.                                                          */
  /* If more than one tcp_mss data could be sent, then the sending must be done  */
  /* one segment at a time i.e., one call to output_pkt() per segment.           */

  /* don't worry about  silly window avoidance.                                  */
  

  /* If after all this, a segment can be sent, then :                            */

     /* If the segment being sent is a new segment (snd_nxt + segment len > snd_max) */
     /* and retransmission timer is not set (!tcp_layer->tcp_t_rtt)                 */
     /* then set the timer to time the segment being sent.
	     tcp_layer->tcp_t_rtt = 1;      
	     tcp_layer->tcp_rtseq = sequence number of segment being sent;
     */

     /*  Update snd_nxt   */
     /*  call output_pkt to send one segment  */

  /* check to see if more segments can be sent, and if so, */
  /* send them as above else return    */


  return (1);
}

output_pkt(TCP_LAYER_ENTITY_TYPE *tcp_layer, int offset, int len, int samplenow) 
/* Although you don't need to modify this function, you do need to study it */
/* carefully and understand what this is doing */
/* output_pkt: This is called by tcp_output when a segment is to be sent   */
/* output_pkt should extract the segment from the send_queue with sequence */
/* number = offset, and call tcp_to_datalink() to send the T_PDU           */
/* offset is the starting sequence number of the segment to be sent */
/* len is the length of the segment to be sent   */
/* samplenow is 1 if RTT timer must be activated: you can ignore this field */
{
     PDU_TYPE *pkt;

     /* Create a PDU, and make into a T_PDU_TYPE */
     /* fill in the fields you know */
     pkt = (PDU_TYPE *) pdu_alloc();
     pkt->type = TYPE_IS_T_PDU;
     pkt->u.t_pdu.tcp_hdr.pk_checksum = 0;
     pkt->u.t_pdu.tcp_hdr.pk_seq = offset;
     pkt->u.t_pdu.tcp_hdr.pk_len = len;

     /* Remove the appropriate a_pdu of length len from tcp_send_queue */
     if (len) {
        Get_pdu_from_send_queue(tcp_layer, pkt, offset);
	/* This function fills pkt with the A_PDU stored int he send_buffer */
    }


     
     pkt->u.t_pdu.tcp_hdr.snode = tcp_layer->tcp_my_addr;
     pkt->u.t_pdu.tcp_hdr.dnode = tcp_layer->tcp_peer_addr;

     /* Important: the ack field is set with the next expected packet */
     pkt->u.t_pdu.tcp_hdr.pk_ack = tcp_layer->tcp_rcv_nxt;


     /* Do not remove the next line */
     Log_pkt_stats(tcp_layer, pkt) ;    /* do some logging of statistics */
                              

     /* send pdu to DLC layer */
      send_pdu_to_datalink(tcp_layer,pkt);

#ifdef DEBUG
      dbg_write(debug_log, DBG_INFO, tcp_layer,"processed output_pkt()");
#endif

}

tcp_input(TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu)
/*  You don't need to modify this function, but you need to change other */
/* functions called by this function, so study this carefully            */
/*  tcp_input: called when a packet is received from the datalink layer  */
{

  int Free_pkt = TRUE;
  T_PDU_TYPE *pkt = &(pdu->u.t_pdu);

  /* If packet is corrupted, simply discard it. */
  if (pkt->tcp_hdr.pk_checksum) {
	  pdu_free(pdu);
          dprintf(30,"Packet was corrupted\n");
	  return;
  }


  /* Perform some preprocessing on this packet */
  update_rto(tcp_layer,pdu);   /* updates round trip timer calculations */
  trim_pkt(tcp_layer, pdu);    /* delete the duplicate parts of packet  */
  
  /* Now if the packet contains an ACK, process the ACK */
  process_ack(tcp_layer, pdu);

  /* Now process the data part of the packet */
  /* if the packet length is > 0 then the entire contents of the */
  /* packet are non-duplicate, else trim_pkt() would have trimmed it*/
  if (pkt->tcp_hdr.pk_len > 0) { 
    /* If the pkt begins at tcp_layer->tcp_rcv_nxt, process it; otherwise, buffer it */
    if(pkt->tcp_hdr.pk_seq == tcp_layer->tcp_rcv_nxt) {
	process_insequence_pkt(tcp_layer,pdu);
    } else {
	process_outofsequence_pkt(tcp_layer,pdu);
    }
  }

  /* Send new data if we can (else an ACK for what we need)  */
  tcp_output(tcp_layer);

#ifdef DEBUG
      dbg_write(debug_log, DBG_INFO, tcp_layer,"processed MY_SEG_ARRIVES");
#endif
}
/*********************************************************************/
static int
process_insequence_pkt(TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu)
{

  /* The packet is in sequence. Send the packet to the application layer */
  /* and update rcv_nxt */

  /* Process as many pkts as possible from the reseq queue*/
    Process_packets_from_resequence_queue(tcp_layer,pdu); 
  /* This function updates the rcv_nxt for each packet it sends the application */

  /* Set the ack flag so that an ack can be sent */

return 0;
}
/*********************************************************************/
static int
process_outofsequence_pkt(TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu)
{

  /* If doing fast retransmit, then store the packet in the resequence quene */
  /* Use Insert pdu_into_resequence_queue() and fast_rexmit()  */
  
  /* An ack should also be sent */

return 0; 
}
/*********************************************************************/
static int
process_ack(TCP_LAYER_ENTITY_TYPE *tcp_layer, PDU_TYPE *pdu)
/* process_ack: process the pk_ack field of the tcp_hdr of the pdu */
/* You don't need to modify this function, but study it carefully */
{

  int acked_bytes_num;
  T_PDU_TYPE *pkt = &(pdu->u.t_pdu);


  /* update snd_nxt */ 
  if (tcp_layer->tcp_snd_nxt < pkt->tcp_hdr.pk_ack)
	    tcp_layer->tcp_snd_nxt = pkt->tcp_hdr.pk_ack;

  if (tcp_layer->tcp_snd_una < pkt->tcp_hdr.pk_ack && 
      pkt->tcp_hdr.pk_ack <= tcp_layer->tcp_snd_max ) { 
  /* If the ack is not a duplicate ack then : */

	  reset_dupacks(tcp_layer);    
                 /* you need to write this function */

          acked_bytes_num = pkt->tcp_hdr.pk_ack - tcp_layer->tcp_snd_una;
          /* update snd_una */
          tcp_layer->tcp_snd_una = pkt->tcp_hdr.pk_ack;

          /* Function free_acked_data() */ 
          /* Use this to free the data acked by the packet */
          /* Assume this is given to you */
	  free_acked_data(tcp_layer, acked_bytes_num);

          /* perform slow start or congestion avoidance */
          /* you need to write this function */
	  slow_start(tcp_layer);

          /* Function: misc_functions_on_ack() */
          /* This function takes care of some housekeeping */
	  misc_functions_on_ack(tcp_layer);
          /* Function: misc_functions_on_ack() */


  } else if ((pkt->tcp_hdr.pk_len == 0) && fast_rexmit(tcp_layer))  { 
         /* No data, duplicate ack => fast rexmit */
         /*  You need to write this function */
	fast_rexmit_code(tcp_layer, pkt);
  } 

return 0;
}
/*********************************************************************/

static int
reset_dupacks(TCP_LAYER_ENTITY_TYPE *tcp_layer)
{

  /* if (fast_rexmit(tcp_layer))  */

    /* reset congestion window and dupacks if needed */
    /* use update_cwnd(tcp_layer, value) whenever you want */
    /* to change the cwnd value. This ensures that plots are done correctly */


return 0;
}
/*********************************************************************/
static int
slow_start(TCP_LAYER_ENTITY_TYPE *tcp_layer)
{

   /* Open window using Van Jacobson's strategy */
   /* if cwnd > ssthresh then cwnd += mss*mss/cwnd; */
   /* else if cwnd <= ssthresh then cwnd += mss */
   /* cwnd must be less than tcp_snd_wnd */


return 0;

}
/*********************************************************************/
static int
fast_rexmit_code(TCP_LAYER_ENTITY_TYPE *tcp_layer, T_PDU_TYPE *pkt)
/* fast_rexmit_code : executes the fast retransmit and recovery code */
{


  if  (!tcp_layer->tcp_active_retrans_timer || 
        tcp_layer->tcp_snd_una != pkt->tcp_hdr.pk_ack) {
    /* If either the retransmission timer has triggered, or */
    /* the ACK is not a duplicate ack */
    /* reset the duplicate ack count */

        tcp_layer->tcp_dupacks = 0;

  } else if (tcp_layer->tcp_active_retrans_timer && 
             tcp_layer->tcp_snd_una == pkt->tcp_hdr.pk_ack) {

    /* The fast retransmit and recovery algorithm goes here */
    /* Remember to keep ssthresh a multiple of the mss and at least 2 segments */
    /* Use    shut_timer_off(tcp_layer); to turn off the retransmission timer */
    /*         just before you call tcp_output */

  

   }

return 0;
}


static caddr_t
tcp_retrans_timeout(TCP_LAYER_ENTITY_TYPE *tcp_layer)
{

   /* Some notes to remember */
   /* set tcp_layer->tcp_t_rtt = 0 to ensure correct timeout behavior */
   /*  Use timer_backoff(tcp_layer); to backoff timer before calling tcp_output */
   /* ssthresh always in multiples of segment sizes */
   /* use update_cwnd() to update the cwnd value */
   /* Reset dupacks to 0 */
   /* call tcp_output() */

  
   return ((caddr_t)tcp_layer);
}
