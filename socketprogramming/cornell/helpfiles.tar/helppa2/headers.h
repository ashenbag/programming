/* Here are some basic header files to help you start. There probably aremany more you would need. So, either add to these or declare your own. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <assert.h>

#include <signal.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <fcntl.h>

#include <errno.h>
#include <asm/errno.h>

